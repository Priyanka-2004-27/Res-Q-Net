import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { LocationProvider } from './context/LocationContext';
import { Navbar } from './components/Navbar';
import { AlertBanner } from './components/AlertBanner';
import { SosModal } from './components/SosModal';
import { AiAssistantModal } from './components/AiAssistantModal';
import { EditProfileModal } from './components/EditProfileModal';
import { Home } from './pages/Home';
import { CitizenDashboard } from './pages/CitizenDashboard';
import { HelperDashboard } from './pages/HelperDashboard';
import { AdminDashboard } from './pages/AdminDashboard';
import { SafetyGuides } from './pages/SafetyGuides';

function AppContent() {
  const [activeTab, setActiveTab] = useState('home');
  const [isSosOpen, setIsSosOpen] = useState(false);
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);

  const handleSosSubmitted = () => {
    setActiveTab('citizen');
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenSos={() => setIsSosOpen(true)}
        onOpenAi={() => setIsAiOpen(true)}
        onOpenEditProfile={() => setIsEditProfileOpen(true)}
      />

      <AlertBanner />

      <main style={{ flex: 1 }}>
        {activeTab === 'home' && (
          <Home
            onOpenSos={() => setIsSosOpen(true)}
            onOpenAi={() => setIsAiOpen(true)}
            onSwitchTab={setActiveTab}
          />
        )}
        {activeTab === 'citizen' && (
          <CitizenDashboard
            onOpenSos={() => setIsSosOpen(true)}
            onOpenAi={() => setIsAiOpen(true)}
          />
        )}
        {activeTab === 'helper' && <HelperDashboard />}
        {activeTab === 'admin' && <AdminDashboard />}
        {activeTab === 'guides' && <SafetyGuides />}
      </main>

      <SosModal
        isOpen={isSosOpen}
        onClose={() => setIsSosOpen(false)}
        onSosSubmitted={handleSosSubmitted}
      />

      <AiAssistantModal
        isOpen={isAiOpen}
        onClose={() => setIsAiOpen(false)}
      />

      <EditProfileModal
        isOpen={isEditProfileOpen}
        onClose={() => setIsEditProfileOpen(false)}
      />

      <footer style={{ backgroundColor: '#0b0f19', borderTop: '1px solid #1e293b', padding: '16px', textAlign: 'center', fontSize: '11px', color: '#64748b' }}>
        <strong>ResQNet</strong> — Silver Oak University Department of Computer Engineering
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <LocationProvider>
        <AppContent />
      </LocationProvider>
    </AuthProvider>
  );
}
