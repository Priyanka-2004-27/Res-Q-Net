import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { AlertTriangle, AlertCircle, ChevronDown, ChevronUp } from 'lucide-react';

export const AlertBanner = () => {
  const [alerts, setAlerts] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const res = await api.get('/alerts');
        if (res.data.success && res.data.data.length > 0) {
          setAlerts(res.data.data);
        }
      } catch (err) {
        console.warn('Could not fetch active disaster alerts:', err.message);
      }
    };

    fetchAlerts();
    const interval = setInterval(fetchAlerts, 30000);
    return () => clearInterval(interval);
  }, []);

  if (!alerts || alerts.length === 0) return null;

  const currentAlert = alerts[currentIndex] || alerts[0];
  const isCritical = currentAlert.severity === 'critical';

  return (
    <div style={{
      backgroundColor: isCritical ? '#450a0a' : '#451a03',
      borderBottom: `1px solid ${isCritical ? '#991b1b' : '#b45309'}`,
      color: '#fef2f2',
    }}>
      <div style={{
        maxWidth: '1440px',
        margin: '0 auto',
        padding: '10px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '10px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flex: 1 }}>
          <div style={{
            padding: '6px',
            borderRadius: '6px',
            backgroundColor: isCritical ? '#dc2626' : '#d97706',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
            {isCritical ? <AlertTriangle size={18} color="#fff" /> : <AlertCircle size={18} color="#fff" />}
          </div>

          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{
                fontSize: '11px',
                fontWeight: '800',
                textTransform: 'uppercase',
                padding: '2px 6px',
                borderRadius: '4px',
                backgroundColor: isCritical ? '#ef4444' : '#f59e0b',
                color: '#fff',
              }}>
                {currentAlert.severity} ALERT
              </span>
              <span style={{ fontSize: '14px', fontWeight: '700' }}>{currentAlert.title}</span>
            </div>
            <p style={{ fontSize: '12px', color: '#fca5a5', marginTop: '2px', margin: 0 }}>
              Zone: <strong>{currentAlert.affectedAreaName}</strong> | Issued by {currentAlert.sourceAuthority}
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsExpanded(!isExpanded)}
          style={{
            fontSize: '12px',
            fontWeight: '600',
            padding: '6px 12px',
            borderRadius: '6px',
            backgroundColor: 'rgba(255, 255, 255, 0.15)',
            color: '#ffffff',
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
          }}
        >
          {isExpanded ? 'Hide' : 'Directives'}
          {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
        </button>
      </div>

      {isExpanded && (
        <div style={{
          maxWidth: '1440px',
          margin: '0 auto',
          padding: '16px 20px',
          borderTop: '1px solid rgba(255,255,255,0.1)',
          backgroundColor: 'rgba(0, 0, 0, 0.25)',
        }}>
          <p style={{ fontSize: '13px', color: '#fecaca', marginBottom: '8px' }}>
            {currentAlert.summary}
          </p>
          <ul style={{ paddingLeft: '20px', fontSize: '12px', color: '#fee2e2' }}>
            {currentAlert.instructions && currentAlert.instructions.map((inst, idx) => (
              <li key={idx} style={{ marginBottom: '3px' }}>{inst}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
