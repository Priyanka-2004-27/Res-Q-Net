const express = require('express');
const http = require('http');
const cors = require('cors');
const dotenv = require('dotenv');
const { Server } = require('socket.io');

dotenv.config();

const { connectDB } = require('./config/db');
const { notFound, errorHandler } = require('./middleware/errorMiddleware');

// Route imports
const authRoutes = require('./routes/authRoutes');
const helpRequestRoutes = require('./routes/helpRequestRoutes');
const alertRoutes = require('./routes/alertRoutes');
const resourceRoutes = require('./routes/resourceRoutes');
const aiRoutes = require('./routes/aiRoutes');

const app = express();
const server = http.createServer(app);

// Initialize Socket.io
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
  },
});

// Attach io to express app so controllers can emit events
app.set('io', io);

// Global Middleware
app.use(cors());
app.use(express.json());

// Socket.io Real-time Event Listeners
io.on('connection', (socket) => {
  console.log(`📡 Client connected to ResQNet real-time socket: ${socket.id}`);

  // Helper broadcasts live GPS location
  socket.on('helper_location_update', (data) => {
    // data: { helperId, coords: [lng, lat], requestId }
    io.emit('helper_location_broadcast', data);
  });

  socket.on('disconnect', () => {
    console.log(`🔌 Client disconnected: ${socket.id}`);
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/requests', helpRequestRoutes);
app.use('/api/alerts', alertRoutes);
app.use('/api/resources', resourceRoutes);
app.use('/api/ai', aiRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    platform: 'ResQNet Disaster Assistance Platform',
    version: '1.0.0',
    timestamp: new Date(),
  });
});

// Error handling middleware
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

// Connect to MongoDB and start server
connectDB().then(() => {
  server.listen(PORT, () => {
    console.log(`🚀 ResQNet Backend API running on port ${PORT}`);
    console.log(`🌐 Health check available at http://localhost:${PORT}/api/health`);
  });
});
