# ResQNet — Disaster Assistance & Emergency Response Platform

> **Minor Project ID:** 10101043494  
> **Institution:** Silver Oak University, Department of Computer Engineering  
> **Students:** Kahan Gandhi (2401031830017), Priyanka Mohanty (2301031830012)  
> **Guide:** Ms. Vaishvari Desai  

---

## 🛠️ Complete Tech Stack
* **Frontend:** React.js, Vite, Leaflet, OpenStreetMap, CSS3
* **Backend:** Node.js, Express.js, Socket.io, JWT, Bcryptjs
* **Database:** MongoDB (with Mongoose schemas & In-Memory Fallback)
* **Maps & Location:** Geolocation API, Haversine formula, 5-50km radius search
* **AI:** ResQ AI incident triage & disaster assistant

## 🚀 How to Run
1. Double-click `start_all.bat`.
2. Open `http://localhost:3000` in your browser.
