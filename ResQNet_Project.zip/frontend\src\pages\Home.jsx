import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { useLocation } from '../context/LocationContext';
import { EmergencyMap } from '../components/EmergencyMap';
import {
  AlertTriangle,
  Radio,
  PhoneCall,
  Bot,
  Building,
  LifeBuoy,
  Flame,
  Shield,
  Utensils,
  Droplet,
  Layers,
  Activity,
  Waves,
  Wind,
  HeartPulse,
  Sun,
  Search,
  ExternalLink,
  ChevronRight,
  ShieldAlert,
  Clock,
  UserCheck,
  CheckCircle2,
  Cpu,
  Compass,
} from 'lucide-react';

export const Home = ({ onOpenSos, onOpenAi, onSwitchTab }) => {
  const { address, lat, lng } = useLocation();

  const [requests, setRequests] = useState([]);
  const [resources, setResources] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [selectedDisasterCategory, setSelectedDisasterCategory] = useState('all');
  const [resourceFilterType, setResourceFilterType] = useState('all');
  const [searchResource, setSearchResource] = useState('');
  const [selectedIncidentUrgency, setSelectedIncidentUrgency] = useState('all');
  const [activeAlertIndex, setActiveAlertIndex] = useState(0);

  const loadData = async () => {
    try {
      const [reqRes, resRes, alertRes] = await Promise.all([
        api.get('/requests'),
        api.get('/resources'),
        api.get('/alerts'),
      ]);
      if (reqRes.data.success) setRequests(reqRes.data.data);
      if (resRes.data.success) setResources(resRes.data.data);
      if (alertRes.data.success) setAlerts(alertRes.data.data);
    } catch (err) {
      console.warn('Map load:', err.message);
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 15000);
    return () => clearInterval(interval);
  }, []);

  // Cycle ticker alerts
  useEffect(() => {
    if (alerts.length <= 1) return;
    const ticker = setInterval(() => {
      setActiveAlertIndex((prev) => (prev + 1) % alerts.length);
    }, 6000);
    return () => clearInterval(ticker);
  }, [alerts.length]);

  // Statistics calculation
  const totalCasualties = requests.reduce((acc, r) => acc + (r.casualtiesCount || 0), 0);
  const activeIncidents = requests.filter((r) => r.status !== 'resolved').length;
  const criticalSosCount = requests.filter((r) => r.urgencyLevel === 'critical').length;
  const totalShelterCapacity = resources
    .filter((r) => r.type === 'shelter' || r.type === 'relief_camp' || r.type === 'evacuation_center')
    .reduce((acc, r) => acc + (r.capacity || 0), 0);
  const currentShelterOccupancy = resources
    .filter((r) => r.type === 'shelter' || r.type === 'relief_camp' || r.type === 'evacuation_center')
    .reduce((acc, r) => acc + (r.currentOccupancy || 0), 0);

  // Disaster Category definitions
  const disasterCategories = [
    { id: 'all', label: 'All Incidents', icon: Layers, count: requests.length },
    { id: 'flood', label: 'Flood & Water', icon: Waves, count: requests.filter((r) => r.category === 'flood').length },
    { id: 'earthquake', label: 'Earthquake', icon: Activity, count: requests.filter((r) => r.category === 'earthquake').length },
    { id: 'fire', label: 'Fire & Blast', icon: Flame, count: requests.filter((r) => r.category === 'fire').length },
    { id: 'cyclone', label: 'Cyclone & Storm', icon: Wind, count: requests.filter((r) => r.category === 'cyclone').length },
    { id: 'medical', label: 'Medical & Trauma', icon: HeartPulse, count: requests.filter((r) => r.category === 'medical').length },
    { id: 'building_collapse', label: 'Collapse & USAR', icon: Building, count: requests.filter((r) => r.category === 'building_collapse').length },
    { id: 'food_water', label: 'Food & Clean Water', icon: Utensils, count: requests.filter((r) => r.category === 'food_water').length },
    { id: 'rescue_evacuation', label: 'Rescue & Evac', icon: LifeBuoy, count: requests.filter((r) => r.category === 'rescue_evacuation').length },
    { id: 'chemical_hazard', label: 'Hazmat & Gas', icon: ShieldAlert, count: requests.filter((r) => r.category === 'industrial_hazard').length },
  ];

  // Filtered requests
  const filteredRequests = requests.filter((req) => {
    if (selectedDisasterCategory !== 'all' && req.category !== selectedDisasterCategory) return false;
    if (selectedIncidentUrgency !== 'all' && req.urgencyLevel !== selectedIncidentUrgency) return false;
    return true;
  });

  // Filtered resources
  const filteredResources = resources.filter((res) => {
    if (resourceFilterType !== 'all' && res.type !== resourceFilterType) return false;
    if (searchResource) {
      const q = searchResource.toLowerCase();
      return (
        res.name.toLowerCase().includes(q) ||
        res.address.toLowerCase().includes(q) ||
        (res.availableSupplies && res.availableSupplies.some((s) => s.toLowerCase().includes(q)))
      );
    }
    return true;
  });

  const activeAlert = alerts[activeAlertIndex] || alerts[0];

  return (
    <div style={{ paddingBottom: '60px' }}>
      {/* 1. Live Emergency Flash Ticker */}
      {activeAlert && (
        <div style={{
          backgroundColor: activeAlert.severity === 'critical' ? '#7f1d1d' : '#78350f',
          color: '#ffffff',
          padding: '8px 20px',
          borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '10px',
          fontSize: '12px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{
              backgroundColor: '#ef4444',
              color: '#fff',
              fontSize: '10px',
              fontWeight: '800',
              padding: '2px 6px',
              borderRadius: '4px',
              letterSpacing: '0.05em',
            }}>
              {activeAlert.severity.toUpperCase()} ALERT
            </span>
            <strong>{activeAlert.title}</strong>
            <span style={{ color: '#fcd34d', display: 'none', md: 'inline' }}>
              — {activeAlert.affectedAreaName}
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{ color: '#cbd5e1', fontSize: '11px' }}>
              Authority: {activeAlert.sourceAuthority}
            </span>
            <button
              onClick={() => onSwitchTab('guides')}
              style={{
                background: 'rgba(255,255,255,0.2)',
                color: '#fff',
                fontSize: '11px',
                fontWeight: '700',
                padding: '3px 8px',
                borderRadius: '4px',
                cursor: 'pointer',
              }}
            >
              Action Guide →
            </button>
          </div>
        </div>
      )}

      {/* 2. Command Hero Header */}
      <section style={{ backgroundColor: '#0f172a', borderBottom: '1px solid #1e293b', padding: '24px 20px' }}>
        <div style={{ maxWidth: '1440px', margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '20px' }}>
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '3px 10px', borderRadius: '9999px', backgroundColor: 'rgba(239, 68, 68, 0.15)', color: '#f87171', fontSize: '11px', fontWeight: '800', marginBottom: '8px', border: '1px solid rgba(239, 68, 68, 0.3)' }}>
              <Radio size={12} className="beacon-pulse" /> 24/7 EMERGENCY OPERATIONS CENTER (EOC)
            </div>
            <h1 style={{ fontSize: '26px', fontWeight: '800', color: '#f8fafc', margin: 0, letterSpacing: '-0.02em' }}>
              ResQNet Emergency Command & Resource Network
            </h1>
            <p style={{ fontSize: '13px', color: '#94a3b8', margin: '4px 0 0', maxWidth: '750px' }}>
              Unified multi-lateral platform integrating Citizens, Verified Volunteers, First Responders, and AI Triage into an active geo-radius rescue ecosystem.
            </p>
          </div>

          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <button
              onClick={onOpenAi}
              style={{
                padding: '11px 18px',
                borderRadius: '8px',
                backgroundColor: '#1e293b',
                border: '1px solid #4f46e5',
                color: '#a5b4fc',
                fontSize: '13px',
                fontWeight: '700',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                cursor: 'pointer',
                boxShadow: '0 0 15px rgba(79, 70, 229, 0.25)',
              }}
            >
              <Bot size={18} color="#818cf8" />
              <span>ResQ AI Assistant</span>
            </button>
            <button
              onClick={onOpenSos}
              className="sos-glow-button"
              style={{
                padding: '11px 22px',
                borderRadius: '8px',
                color: '#ffffff',
                fontSize: '14px',
                fontWeight: '800',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                cursor: 'pointer',
                letterSpacing: '0.03em',
              }}
            >
              <AlertTriangle size={18} />
              <span>TRIGGER INSTANT SOS</span>
            </button>
          </div>
        </div>
      </section>

      {/* 3. Live Operational Dashboard Stats Matrix */}
      <section style={{ maxWidth: '1440px', margin: '20px auto 0', padding: '0 20px' }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: '14px',
        }}>
          {/* Stat 1: SOS Distress */}
          <div className="resq-card" style={{ borderLeft: '4px solid #ef4444', padding: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
              <span style={{ fontSize: '11px', fontWeight: '800', color: '#f87171', textTransform: 'uppercase' }}>Active SOS Distress</span>
              <AlertTriangle size={18} color="#ef4444" />
            </div>
            <div style={{ fontSize: '24px', fontWeight: '800', color: '#f8fafc' }}>
              {activeIncidents} <span style={{ fontSize: '13px', color: '#f87171', fontWeight: '600' }}>({criticalSosCount} Critical)</span>
            </div>
            <p style={{ fontSize: '11px', color: '#94a3b8', margin: '4px 0 0' }}>{totalCasualties} casualties reported in radius</p>
          </div>

          {/* Stat 2: Active Responders */}
          <div className="resq-card" style={{ borderLeft: '4px solid #10b981', padding: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
              <span style={{ fontSize: '11px', fontWeight: '800', color: '#34d399', textTransform: 'uppercase' }}>Field Responders</span>
              <UserCheck size={18} color="#10b981" />
            </div>
            <div style={{ fontSize: '24px', fontWeight: '800', color: '#f8fafc' }}>
              4 Deployed <span style={{ fontSize: '13px', color: '#34d399', fontWeight: '600' }}>(2 En Route)</span>
            </div>
            <p style={{ fontSize: '11px', color: '#94a3b8', margin: '4px 0 0' }}>Volunteers, Medics & Boat Squads</p>
          </div>

          {/* Stat 3: Shelters Capacity */}
          <div className="resq-card" style={{ borderLeft: '4px solid #3b82f6', padding: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
              <span style={{ fontSize: '11px', fontWeight: '800', color: '#60a5fa', textTransform: 'uppercase' }}>Shelters & Evac Capacity</span>
              <LifeBuoy size={18} color="#3b82f6" />
            </div>
            <div style={{ fontSize: '24px', fontWeight: '800', color: '#f8fafc' }}>
              {currentShelterOccupancy} / {totalShelterCapacity}
            </div>
            <div style={{ background: '#334155', height: '6px', borderRadius: '3px', marginTop: '6px', overflow: 'hidden' }}>
              <div style={{ background: '#3b82f6', width: `${Math.min(Math.round((currentShelterOccupancy / (totalShelterCapacity || 1)) * 100), 100)}%`, height: '100%' }} />
            </div>
          </div>

          {/* Stat 4: Broadcast Early Warnings */}
          <div className="resq-card" style={{ borderLeft: '4px solid #f59e0b', padding: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
              <span style={{ fontSize: '11px', fontWeight: '800', color: '#fbbf24', textTransform: 'uppercase' }}>Active Early Warnings</span>
              <Radio size={18} color="#f59e0b" />
            </div>
            <div style={{ fontSize: '24px', fontWeight: '800', color: '#f8fafc' }}>
              {alerts.length} Warnings <span style={{ fontSize: '13px', color: '#fbbf24', fontWeight: '600' }}>(GSDMA / IMD)</span>
            </div>
            <p style={{ fontSize: '11px', color: '#94a3b8', margin: '4px 0 0' }}>Covers flood, cyclone, tremor, and heatwave</p>
          </div>
        </div>
      </section>

      {/* 4. ALL DISASTER CATEGORIES EXPLORER (Sabhi Categories Ribbon) */}
      <section style={{ maxWidth: '1440px', margin: '24px auto 0', padding: '0 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
          <div>
            <h2 style={{ fontSize: '16px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>
              All Emergency Disaster Categories
            </h2>
            <p style={{ fontSize: '12px', color: '#94a3b8', margin: '2px 0 0' }}>
              Filter live incidents, triage protocols, and action units across all 10 disaster classifications
            </p>
          </div>
          <button
            onClick={() => onSwitchTab('guides')}
            style={{ fontSize: '12px', color: '#38bdf8', fontWeight: '700', background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}
          >
            <span>View All Survival Manuals</span>
            <ChevronRight size={14} />
          </button>
        </div>

        <div style={{
          display: 'flex',
          gap: '8px',
          overflowX: 'auto',
          paddingBottom: '8px',
        }}>
          {disasterCategories.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedDisasterCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedDisasterCategory(cat.id)}
                style={{
                  padding: '8px 14px',
                  borderRadius: '10px',
                  backgroundColor: isSelected ? '#2563eb' : '#1e293b',
                  color: isSelected ? '#ffffff' : '#cbd5e1',
                  border: isSelected ? '1px solid #3b82f6' : '1px solid #334155',
                  fontSize: '12px',
                  fontWeight: '700',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  whiteSpace: 'nowrap',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                  boxShadow: isSelected ? '0 0 12px rgba(37, 99, 235, 0.4)' : 'none',
                }}
              >
                <Icon size={14} />
                <span>{cat.label}</span>
                <span style={{
                  padding: '2px 6px',
                  borderRadius: '9999px',
                  backgroundColor: isSelected ? '#1e3a8a' : '#0f172a',
                  color: isSelected ? '#93c5fd' : '#94a3b8',
                  fontSize: '10px',
                }}>
                  {cat.count}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* 5. Live Tactical Geospatial Radar Map */}
      <section style={{ maxWidth: '1440px', margin: '20px auto 0', padding: '0 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px', flexWrap: 'wrap', gap: '8px' }}>
          <div>
            <h2 style={{ fontSize: '16px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>
              Live Emergency Radar & Radius Locator
            </h2>
            <p style={{ fontSize: '12px', color: '#94a3b8', margin: '2px 0 0' }}>
              Multi-layered GIS overlay displaying active distress signals, shelters, medical hubs, and rescue posts.
            </p>
          </div>
          <span style={{ fontSize: '12px', color: '#38bdf8', fontWeight: '600', backgroundColor: '#1e293b', padding: '4px 10px', borderRadius: '6px', border: '1px solid #334155' }}>
            📍 Your GPS: {address}
          </span>
        </div>

        <EmergencyMap helpRequests={requests} resources={resources} />
      </section>

      {/* 6. Two-Column Grid: Active SOS Feed & Resources Directory */}
      <section style={{ maxWidth: '1440px', margin: '28px auto 0', padding: '0 20px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))', gap: '24px' }}>
        
        {/* Left Column: Live SOS Distress Feed */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap', gap: '8px' }}>
            <div>
              <h2 style={{ fontSize: '16px', fontWeight: '800', color: '#f8fafc', margin: 0, display: 'flex', alignItems: 'center', gap: '6px' }}>
                <AlertTriangle size={16} color="#ef4444" /> Live SOS Incident Distress Feed
              </h2>
              <span style={{ fontSize: '11px', color: '#94a3b8' }}>
                {filteredRequests.length} distress calls matching category & urgency
              </span>
            </div>

            {/* Urgency Filter */}
            <div style={{ display: 'flex', gap: '4px' }}>
              {['all', 'critical', 'high', 'medium'].map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setSelectedIncidentUrgency(lvl)}
                  style={{
                    padding: '4px 8px',
                    borderRadius: '6px',
                    fontSize: '11px',
                    fontWeight: '700',
                    textTransform: 'uppercase',
                    backgroundColor: selectedIncidentUrgency === lvl ? '#334155' : 'transparent',
                    color: selectedIncidentUrgency === lvl ? '#f8fafc' : '#94a3b8',
                    border: '1px solid #334155',
                    cursor: 'pointer',
                  }}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', maxHeight: '680px', overflowY: 'auto', paddingRight: '4px' }}>
            {filteredRequests.map((req) => {
              const isCritical = req.urgencyLevel === 'critical' || req.aiTriageReport?.riskScore >= 8;
              return (
                <div
                  key={req._id}
                  className="resq-card"
                  style={{
                    backgroundColor: '#111827',
                    borderLeft: `4px solid ${isCritical ? '#ef4444' : req.urgencyLevel === 'high' ? '#f59e0b' : '#3b82f6'}`,
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '6px' }}>
                    <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
                      <span style={{
                        fontSize: '10px',
                        fontWeight: '800',
                        textTransform: 'uppercase',
                        padding: '2px 6px',
                        borderRadius: '4px',
                        backgroundColor: isCritical ? 'rgba(239, 68, 68, 0.2)' : 'rgba(245, 158, 11, 0.2)',
                        color: isCritical ? '#f87171' : '#fbbf24',
                        border: `1px solid ${isCritical ? 'rgba(239, 68, 68, 0.4)' : 'rgba(245, 158, 11, 0.4)'}`,
                      }}>
                        {req.urgencyLevel} SOS
                      </span>
                      <span style={{ fontSize: '11px', color: '#94a3b8', textTransform: 'uppercase', fontWeight: '700' }}>
                        ● {req.category.replace('_', ' ')}
                      </span>
                    </div>

                    <span style={{
                      fontSize: '11px',
                      fontWeight: '700',
                      color: req.status === 'in_progress' ? '#38bdf8' : req.status === 'assigned' ? '#34d399' : '#f59e0b',
                    }}>
                      Status: {req.status.replace('_', ' ')}
                    </span>
                  </div>

                  <h3 style={{ fontSize: '14px', fontWeight: '800', color: '#f8fafc', margin: '0 0 4px' }}>
                    {req.title}
                  </h3>
                  <p style={{ fontSize: '12px', color: '#cbd5e1', margin: '0 0 10px', lineHeight: 1.5 }}>
                    {req.description}
                  </p>

                  {/* AI Triage Snippet */}
                  {req.aiTriageReport && (
                    <div style={{
                      backgroundColor: '#1e293b',
                      padding: '8px 10px',
                      borderRadius: '8px',
                      marginBottom: '10px',
                      fontSize: '11px',
                      border: '1px solid #334155',
                    }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                        <span style={{ color: '#818cf8', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <Bot size={12} /> AI Risk Triage:
                        </span>
                        <strong style={{ color: req.aiTriageReport.riskScore >= 8 ? '#f87171' : '#fbbf24' }}>
                          Score {req.aiTriageReport.riskScore}/10 — {req.aiTriageReport.severityLabel}
                        </strong>
                      </div>
                      <div style={{ color: '#94a3b8' }}>
                        Dispatch: {(req.aiTriageReport.recommendedServices || []).join(', ')}
                      </div>
                    </div>
                  )}

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px', borderTop: '1px solid #1e293b', paddingTop: '8px', fontSize: '11px', color: '#94a3b8' }}>
                    <div>
                      📍 {req.address} | Casualties: <strong style={{ color: '#f8fafc' }}>{req.casualtiesCount}</strong>
                    </div>
                    <a
                      href={`tel:${req.userPhone}`}
                      style={{
                        padding: '4px 10px',
                        backgroundColor: '#dc2626',
                        color: '#fff',
                        borderRadius: '6px',
                        fontWeight: '700',
                        textDecoration: 'none',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                      }}
                    >
                      <PhoneCall size={12} /> Call ({req.userPhone})
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: All Verified Resources Directory */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap', gap: '8px' }}>
            <div>
              <h2 style={{ fontSize: '16px', fontWeight: '800', color: '#f8fafc', margin: 0, display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Building size={16} color="#38bdf8" /> Verified Emergency Infrastructure
              </h2>
              <span style={{ fontSize: '11px', color: '#94a3b8' }}>
                {filteredResources.length} facilities verified and operational
              </span>
            </div>

            {/* Search Input */}
            <div style={{ position: 'relative', width: '220px' }}>
              <Search size={14} style={{ position: 'absolute', left: '8px', top: '50%', transform: 'translateY(-50%)', color: '#64748b' }} />
              <input
                type="text"
                placeholder="Search facility or supply..."
                value={searchResource}
                onChange={(e) => setSearchResource(e.target.value)}
                style={{ padding: '6px 10px 6px 28px', fontSize: '12px', height: '32px' }}
              />
            </div>
          </div>

          {/* Resource Filter Tabs */}
          <div style={{ display: 'flex', gap: '6px', overflowX: 'auto', paddingBottom: '8px', marginBottom: '12px' }}>
            {[
              { id: 'all', label: 'All' },
              { id: 'hospital', label: 'Hospitals' },
              { id: 'shelter', label: 'Shelters' },
              { id: 'evacuation_center', label: 'Evac Staging' },
              { id: 'fire_station', label: 'Fire & Rescue' },
              { id: 'police_station', label: 'Police HQ' },
              { id: 'food_distribution', label: 'Food & Ration' },
              { id: 'blood_bank', label: 'Blood Banks' },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setResourceFilterType(t.id)}
                style={{
                  padding: '5px 10px',
                  borderRadius: '6px',
                  fontSize: '11px',
                  fontWeight: '700',
                  whiteSpace: 'nowrap',
                  backgroundColor: resourceFilterType === t.id ? '#2563eb' : '#1e293b',
                  color: resourceFilterType === t.id ? '#fff' : '#cbd5e1',
                  border: resourceFilterType === t.id ? '1px solid #3b82f6' : '1px solid #334155',
                  cursor: 'pointer',
                }}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', maxHeight: '680px', overflowY: 'auto', paddingRight: '4px' }}>
            {filteredResources.map((res) => {
              const percentOccupied = res.capacity > 0 ? Math.round((res.currentOccupancy / res.capacity) * 100) : 0;
              return (
                <div key={res._id} className="resq-card" style={{ backgroundColor: '#111827' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                    <span style={{
                      fontSize: '10px',
                      fontWeight: '800',
                      textTransform: 'uppercase',
                      padding: '2px 8px',
                      borderRadius: '4px',
                      backgroundColor: '#1e293b',
                      color: '#38bdf8',
                      border: '1px solid #334155',
                    }}>
                      {res.type.replace('_', ' ')}
                    </span>
                    <span style={{ fontSize: '11px', color: '#34d399', fontWeight: '700' }}>
                      ● {res.operationalStatus}
                    </span>
                  </div>

                  <h3 style={{ fontSize: '14px', fontWeight: '800', color: '#f8fafc', margin: '0 0 4px' }}>
                    {res.name}
                  </h3>
                  <p style={{ fontSize: '12px', color: '#94a3b8', margin: '0 0 8px' }}>
                    📍 {res.address}
                  </p>

                  {/* Occupancy bar */}
                  <div style={{ marginBottom: '8px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1', marginBottom: '3px' }}>
                      <span>Occupancy:</span>
                      <strong style={{ color: percentOccupied > 80 ? '#f87171' : '#34d399' }}>
                        {res.currentOccupancy} / {res.capacity} ({percentOccupied}%)
                      </strong>
                    </div>
                    <div style={{ background: '#334155', height: '6px', borderRadius: '3px', overflow: 'hidden' }}>
                      <div style={{ background: percentOccupied > 80 ? '#ef4444' : '#10b981', width: `${Math.min(percentOccupied, 100)}%`, height: '100%' }} />
                    </div>
                  </div>

                  {/* Available supplies */}
                  {res.availableSupplies && res.availableSupplies.length > 0 && (
                    <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap', marginBottom: '10px' }}>
                      {res.availableSupplies.slice(0, 4).map((s, i) => (
                        <span key={i} style={{ fontSize: '10px', padding: '2px 6px', borderRadius: '4px', backgroundColor: '#1e293b', color: '#cbd5e1' }}>
                          ✓ {s}
                        </span>
                      ))}
                    </div>
                  )}

                  <div style={{ display: 'flex', gap: '8px' }}>
                    <a
                      href={`tel:${res.contactPhone}`}
                      style={{
                        flex: 1,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '6px',
                        padding: '7px',
                        backgroundColor: '#1e293b',
                        border: '1px solid #334155',
                        borderRadius: '6px',
                        color: '#38bdf8',
                        fontSize: '11px',
                        fontWeight: '700',
                        textDecoration: 'none',
                      }}
                    >
                      <PhoneCall size={12} /> {res.contactPhone}
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 7. ALL STRUCTURE VISUALIZER (Platform Enterprise Architecture) */}
      <section style={{ maxWidth: '1440px', margin: '36px auto 0', padding: '0 20px' }}>
        <div className="resq-card" style={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', padding: '24px' }}>
          <div style={{ textAlign: 'center', marginBottom: '20px' }}>
            <span style={{ fontSize: '11px', fontWeight: '800', color: '#818cf8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              PLATFORM SYSTEM ARCHITECTURE & RESCUE LIFECYCLE
            </span>
            <h2 style={{ fontSize: '20px', fontWeight: '800', color: '#f8fafc', margin: '4px 0 0' }}>
              ResQNet End-to-End Emergency Coordination Structure
            </h2>
            <p style={{ fontSize: '13px', color: '#94a3b8', margin: '6px auto 0', maxWidth: '680px' }}>
              From initial GPS distress trigger to AI severity scoring, radius clustering, and field rescue resolution.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '14px' }}>
            {/* Step 1 */}
            <div style={{ backgroundColor: '#111827', border: '1px solid #334155', borderRadius: '10px', padding: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: '#dc2626', color: '#fff', fontSize: '12px', fontWeight: '800', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>1</div>
                <h4 style={{ fontSize: '13px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>Distress Capture</h4>
              </div>
              <p style={{ fontSize: '12px', color: '#94a3b8', margin: 0, lineHeight: 1.5 }}>
                Citizen triggers 1-click SOS. High-accuracy GPS lat/long captured with victim count, medical urgency, and category.
              </p>
            </div>

            {/* Step 2 */}
            <div style={{ backgroundColor: '#111827', border: '1px solid #334155', borderRadius: '10px', padding: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: '#4f46e5', color: '#fff', fontSize: '12px', fontWeight: '800', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>2</div>
                <h4 style={{ fontSize: '13px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>AI Triage Engine</h4>
              </div>
              <p style={{ fontSize: '12px', color: '#94a3b8', margin: 0, lineHeight: 1.5 }}>
                Automated triage algorithms calculate risk score (1-10), produce immediate survival actions, and recommend response squads.
              </p>
            </div>

            {/* Step 3 */}
            <div style={{ backgroundColor: '#111827', border: '1px solid #334155', borderRadius: '10px', padding: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: '#0284c7', color: '#fff', fontSize: '12px', fontWeight: '800', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>3</div>
                <h4 style={{ fontSize: '13px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>Spatial Matching</h4>
              </div>
              <p style={{ fontSize: '12px', color: '#94a3b8', margin: 0, lineHeight: 1.5 }}>
                Haversine distance matrix scans 5km-50km perimeter to locate nearest shelters, ambulances, and active volunteer squads.
              </p>
            </div>

            {/* Step 4 */}
            <div style={{ backgroundColor: '#111827', border: '1px solid #334155', borderRadius: '10px', padding: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: '#059669', color: '#fff', fontSize: '12px', fontWeight: '800', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>4</div>
                <h4 style={{ fontSize: '13px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>Socket Dispatch</h4>
              </div>
              <p style={{ fontSize: '12px', color: '#94a3b8', margin: 0, lineHeight: 1.5 }}>
                WebSocket events push incident notifications instantly to nearby volunteers & paramedics for rapid field acceptance.
              </p>
            </div>

            {/* Step 5 */}
            <div style={{ backgroundColor: '#111827', border: '1px solid #334155', borderRadius: '10px', padding: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: '#d97706', color: '#fff', fontSize: '12px', fontWeight: '800', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>5</div>
                <h4 style={{ fontSize: '13px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>EOC Resolution</h4>
              </div>
              <p style={{ fontSize: '12px', color: '#94a3b8', margin: 0, lineHeight: 1.5 }}>
                Live audit timeline tracks responder arrival, hospital bed allocation, and incident resolution with full accountability.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Official Emergency Speed-Dial Matrix */}
      <section style={{ maxWidth: '1440px', margin: '28px auto 0', padding: '0 20px' }}>
        <h2 style={{ fontSize: '16px', fontWeight: '800', color: '#f8fafc', marginBottom: '12px' }}>
          National & State Disaster Emergency Helplines
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '10px' }}>
          {[
            { num: '112', title: 'National Emergency', desc: 'Universal Integrated Line' },
            { num: '108', title: 'Ambulance & Trauma', desc: 'Medical Emergency' },
            { num: '101', title: 'Fire & Rescue', desc: 'AFES Fire Fighting' },
            { num: '100', title: 'Police Control', desc: 'Public Safety & Cordon' },
            { num: '1077', title: 'Disaster Helpline', desc: 'District Disaster Control' },
            { num: '1070', title: 'State Disaster Cell', desc: 'Gujarat EOC Control' },
            { num: '1091', title: 'Women Safety', desc: 'Women in Distress' },
            { num: '1554', title: 'Coast Guard', desc: 'Maritime & Boat Rescue' },
          ].map((h, i) => (
            <a
              key={i}
              href={`tel:${h.num}`}
              style={{
                backgroundColor: '#111827',
                border: '1px solid #1e293b',
                borderRadius: '8px',
                padding: '10px 14px',
                textDecoration: 'none',
                display: 'block',
                transition: 'border-color 0.2s',
              }}
            >
              <div style={{ fontSize: '18px', fontWeight: '800', color: '#ef4444' }}>{h.num}</div>
              <div style={{ fontSize: '12px', fontWeight: '700', color: '#f8fafc' }}>{h.title}</div>
              <div style={{ fontSize: '10px', color: '#94a3b8' }}>{h.desc}</div>
            </a>
          ))}
        </div>
      </section>
    </div>
  );
};
