const express = require('express');
const router = express.Router();
const {
  createHelpRequest,
  getNearbyRequests,
  acceptHelpRequest,
  updateRequestStatus,
  getMyRequests,
  getAllRequests,
} = require('../controllers/helpRequestController');
const { protect, authorize } = require('../middleware/authMiddleware');

// Get nearby requests (for Helpers/Volunteers)
router.get('/nearby', protect, getNearbyRequests);

// Get logged-in citizen's requests
router.get('/my-requests', protect, getMyRequests);

// Get all requests (Admin / Responders)
router.get('/', protect, getAllRequests);

// Create new SOS Help Request (Citizens)
router.post('/', protect, createHelpRequest);

// Helper accepts request
router.put('/:id/accept', protect, authorize('volunteer', 'responder', 'admin'), acceptHelpRequest);

// Update status (assigned, in_progress, resolved, cancelled)
router.put('/:id/status', protect, updateRequestStatus);

module.exports = router;
