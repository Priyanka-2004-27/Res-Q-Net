const Alert = require('../models/Alert');
const { memoryStore } = require('../config/db');
const { calculateDistanceKm } = require('../services/geoService');

// @desc    Get all active disaster alerts
// @route   GET /api/alerts
// @access  Public
const getActiveAlerts = async (req, res) => {
  try {
    if (memoryStore.isUsingMemoryStore) {
      const active = memoryStore.alerts.filter((a) => a.isActive !== false);
      // Sort critical first
      const order = { critical: 4, warning: 3, watch: 2, advisory: 1 };
      active.sort((a, b) => (order[b.severity] || 0) - (order[a.severity] || 0));
      return res.json({ success: true, count: active.length, data: active });
    }

    const alerts = await Alert.find({ isActive: true }).sort({ createdAt: -1 });
    res.json({ success: true, count: alerts.length, data: alerts });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get alerts affecting user's current GPS location
// @route   GET /api/alerts/nearby
// @access  Public
const getAlertsNearby = async (req, res) => {
  try {
    const lat = parseFloat(req.query.lat);
    const lng = parseFloat(req.query.lng);

    if (isNaN(lat) || isNaN(lng)) {
      return res.status(400).json({ success: false, message: 'Valid lat and lng query params are required' });
    }

    const userCoords = [lng, lat];

    if (memoryStore.isUsingMemoryStore) {
      const matched = memoryStore.alerts.filter((alert) => {
        if (alert.isActive === false) return false;
        const dist = calculateDistanceKm(userCoords, alert.location.coordinates);
        return dist <= (alert.radiusKm || 50);
      });

      return res.json({ success: true, count: matched.length, data: matched });
    }

    // In Mongo: alerts where user is inside radius
    const allActive = await Alert.find({ isActive: true });
    const matched = allActive.filter((alert) => {
      const dist = calculateDistanceKm(userCoords, alert.location.coordinates);
      return dist <= (alert.radiusKm || 50);
    });

    res.json({ success: true, count: matched.length, data: matched });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create new broadcast alert (Admin)
// @route   POST /api/alerts
// @access  Private (Admin)
const createAlert = async (req, res) => {
  try {
    const { title, category, severity, summary, instructions, location, radiusKm, affectedAreaName, sourceAuthority } =
      req.body;

    if (!title || !summary || !category || !severity) {
      return res.status(400).json({ success: false, message: 'Missing required alert details' });
    }

    const alertData = {
      title,
      category,
      severity,
      summary,
      instructions: instructions || [],
      location: location || { type: 'Point', coordinates: [72.5714, 23.0225] },
      radiusKm: Number(radiusKm) || 25,
      affectedAreaName: affectedAreaName || 'Metropolitan Region',
      sourceAuthority: sourceAuthority || req.user.name,
      isActive: true,
      issuedAt: new Date(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
    };

    let savedAlert;
    if (memoryStore.isUsingMemoryStore) {
      alertData._id = '6602' + Date.now().toString().slice(-20);
      memoryStore.alerts.unshift(alertData);
      savedAlert = alertData;
    } else {
      savedAlert = await Alert.create(alertData);
    }

    // Broadcast alert instantly to all connected users
    const io = req.app.get('io');
    if (io) {
      io.emit('new_disaster_alert', savedAlert);
    }

    res.status(201).json({ success: true, data: savedAlert });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getActiveAlerts,
  getAlertsNearby,
  createAlert,
};
