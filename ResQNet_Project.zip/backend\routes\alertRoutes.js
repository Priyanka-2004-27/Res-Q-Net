const express = require('express');
const router = express.Router();
const { getActiveAlerts, getAlertsNearby, createAlert } = require('../controllers/alertController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.get('/', getActiveAlerts);
router.get('/nearby', getAlertsNearby);
router.post('/', protect, authorize('admin', 'responder'), createAlert);

module.exports = router;
