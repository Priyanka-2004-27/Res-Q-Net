const HelpRequest = require('../models/HelpRequest');
const User = require('../models/User');
const { memoryStore } = require('../config/db');
const { performAiTriage } = require('../services/aiService');
const { calculateDistanceKm, estimateEtaMinutes } = require('../services/geoService');

// @desc    Create new Emergency Help Request (SOS) with automated AI Triage
// @route   POST /api/requests
// @access  Private (Citizen/Any authenticated user)
const createHelpRequest = async (req, res) => {
  try {
    const {
      title,
      description,
      category,
      urgencyLevel,
      location, // { type: 'Point', coordinates: [lng, lat] }
      address,
      casualtiesCount,
      needsMedical,
      needsFoodWater,
      needsEvacuation,
      specialAssistance,
    } = req.body;

    if (!title || !location || !location.coordinates || location.coordinates.length < 2) {
      return res.status(400).json({
        success: false,
        message: 'Emergency title and valid GPS coordinates [lng, lat] are required',
      });
    }

    // Run automated AI Triage on the incident
    const aiTriageReport = performAiTriage({
      category: category || 'medical',
      urgencyLevel: urgencyLevel || 'high',
      casualtiesCount: casualtiesCount || 1,
      needsMedical: !!needsMedical,
      needsEvacuation: !!needsEvacuation,
      description: description || '',
    });

    const newRequestData = {
      userId: req.user._id,
      userName: req.user.name,
      userPhone: req.user.phone,
      title,
      description: description || '',
      category: category || 'medical',
      urgencyLevel: urgencyLevel || (aiTriageReport.riskScore >= 8 ? 'critical' : 'high'),
      location: {
        type: 'Point',
        coordinates: location.coordinates,
      },
      address: address || 'GPS Location Captured',
      casualtiesCount: Number(casualtiesCount) || 1,
      needsMedical: !!needsMedical,
      needsFoodWater: !!needsFoodWater,
      needsEvacuation: !!needsEvacuation,
      specialAssistance: specialAssistance || '',
      status: 'pending',
      assignedHelper: { helperId: null },
      statusTimeline: [
        {
          status: 'pending',
          note: 'Emergency SOS triggered by citizen. AI Triage complete.',
          updatedBy: req.user.name,
          timestamp: new Date(),
        },
      ],
      aiTriageReport,
    };

    let savedRequest;

    if (memoryStore.isUsingMemoryStore) {
      newRequestData._id = '6604' + Date.now().toString().slice(-20);
      newRequestData.createdAt = new Date();
      newRequestData.updatedAt = new Date();
      memoryStore.helpRequests.unshift(newRequestData);
      savedRequest = newRequestData;
    } else {
      savedRequest = await HelpRequest.create(newRequestData);
    }

    // Broadcast real-time emergency alert via Socket.io
    const io = req.app.get('io');
    if (io) {
      io.emit('new_emergency_request', {
        request: savedRequest,
        alertType: 'NEW_SOS',
      });
    }

    res.status(201).json({
      success: true,
      message: 'Emergency request submitted and dispatched to nearby helpers',
      data: savedRequest,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get nearby emergency requests within radius (for Helpers/Volunteers)
// @route   GET /api/requests/nearby
// @access  Private (Volunteer/Responder/Admin)
const getNearbyRequests = async (req, res) => {
  try {
    const lat = parseFloat(req.query.lat);
    const lng = parseFloat(req.query.lng);
    const radiusKm = parseFloat(req.query.radius) || 25; // default 25 km
    const status = req.query.status; // optional filter

    if (isNaN(lat) || isNaN(lng)) {
      return res.status(400).json({ success: false, message: 'Valid lat and lng query params are required' });
    }

    const userCoords = [lng, lat];
    let results = [];

    if (memoryStore.isUsingMemoryStore) {
      results = memoryStore.helpRequests
        .filter((reqItem) => {
          if (status && reqItem.status !== status) return false;
          const dist = calculateDistanceKm(userCoords, reqItem.location.coordinates);
          return dist <= radiusKm;
        })
        .map((reqItem) => {
          const dist = calculateDistanceKm(userCoords, reqItem.location.coordinates);
          return {
            ...reqItem,
            distanceKm: dist,
            estimatedEtaMinutes: estimateEtaMinutes(dist),
          };
        })
        .sort((a, b) => a.distanceKm - b.distanceKm);

      return res.json({
        success: true,
        count: results.length,
        radiusKm,
        data: results,
      });
    }

    // MongoDB Geospatial Query using $nearSphere
    const query = {
      location: {
        $nearSphere: {
          $geometry: {
            type: 'Point',
            coordinates: [lng, lat],
          },
          $maxDistance: radiusKm * 1000, // convert km to meters
        },
      },
    };

    if (status) {
      query.status = status;
    }

    const requests = await HelpRequest.find(query);

    results = requests.map((doc) => {
      const item = doc.toObject();
      const dist = calculateDistanceKm(userCoords, item.location.coordinates);
      item.distanceKm = dist;
      item.estimatedEtaMinutes = estimateEtaMinutes(dist);
      return item;
    });

    res.json({
      success: true,
      count: results.length,
      radiusKm,
      data: results,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Helper accepts emergency request (Method/Approach Step 6)
// @route   PUT /api/requests/:id/accept
// @access  Private (Volunteer/Responder)
const acceptHelpRequest = async (req, res) => {
  try {
    const { id } = req.params;
    const helper = req.user;
    const helperCoords = helper.location?.coordinates || [72.5714, 23.0225];

    if (memoryStore.isUsingMemoryStore) {
      const item = memoryStore.helpRequests.find((r) => r._id.toString() === id.toString());
      if (!item) return res.status(404).json({ success: false, message: 'Request not found' });

      if (item.status !== 'pending' && item.status !== 'assigned') {
        return res.status(400).json({ success: false, message: `Request is already ${item.status}` });
      }

      const dist = calculateDistanceKm(helperCoords, item.location.coordinates);
      const eta = estimateEtaMinutes(dist);

      item.status = 'assigned';
      item.assignedHelper = {
        helperId: helper._id,
        helperName: helper.name,
        helperPhone: helper.phone,
        assignedAt: new Date(),
        estimatedArrivalMinutes: eta,
        currentLocation: { type: 'Point', coordinates: helperCoords },
      };

      item.statusTimeline.push({
        status: 'assigned',
        note: `Volunteer/Helper ${helper.name} accepted the mission. ETA ~${eta} mins.`,
        updatedBy: helper.name,
        timestamp: new Date(),
      });

      // Emit socket notification to affected citizen
      const io = req.app.get('io');
      if (io) {
        io.emit(`request_status_update_${item.userId}`, {
          requestId: item._id,
          status: 'assigned',
          helperName: helper.name,
          helperPhone: helper.phone,
          etaMinutes: eta,
          helperLocation: helperCoords,
        });
        io.emit('emergency_request_updated', item);
      }

      return res.json({
        success: true,
        message: 'Request accepted successfully. En route to victim location.',
        data: item,
      });
    }

    const item = await HelpRequest.findById(id);
    if (!item) return res.status(404).json({ success: false, message: 'Request not found' });

    const dist = calculateDistanceKm(helperCoords, item.location.coordinates);
    const eta = estimateEtaMinutes(dist);

    item.status = 'assigned';
    item.assignedHelper = {
      helperId: helper._id,
      helperName: helper.name,
      helperPhone: helper.phone,
      assignedAt: new Date(),
      estimatedArrivalMinutes: eta,
      currentLocation: { type: 'Point', coordinates: helperCoords },
    };

    item.statusTimeline.push({
      status: 'assigned',
      note: `Volunteer/Helper ${helper.name} accepted the mission. ETA ~${eta} mins.`,
      updatedBy: helper.name,
      timestamp: new Date(),
    });

    await item.save();

    const io = req.app.get('io');
    if (io) {
      io.emit(`request_status_update_${item.userId}`, {
        requestId: item._id,
        status: 'assigned',
        helperName: helper.name,
        helperPhone: helper.phone,
        etaMinutes: eta,
        helperLocation: helperCoords,
      });
      io.emit('emergency_request_updated', item);
    }

    res.json({
      success: true,
      message: 'Request accepted successfully. En route to victim location.',
      data: item,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update request status (in_progress, resolved, cancelled)
// @route   PUT /api/requests/:id/status
// @access  Private
const updateRequestStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, note } = req.body;

    const allowedStatuses = ['pending', 'assigned', 'in_progress', 'resolved', 'cancelled'];
    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status' });
    }

    if (memoryStore.isUsingMemoryStore) {
      const item = memoryStore.helpRequests.find((r) => r._id.toString() === id.toString());
      if (!item) return res.status(404).json({ success: false, message: 'Request not found' });

      item.status = status;
      item.statusTimeline.push({
        status,
        note: note || `Status updated to ${status}`,
        updatedBy: req.user.name,
        timestamp: new Date(),
      });

      const io = req.app.get('io');
      if (io) {
        io.emit('emergency_request_updated', item);
        io.emit(`request_status_update_${item.userId}`, {
          requestId: item._id,
          status,
          note,
        });
      }

      return res.json({ success: true, message: `Status updated to ${status}`, data: item });
    }

    const item = await HelpRequest.findById(id);
    if (!item) return res.status(404).json({ success: false, message: 'Request not found' });

    item.status = status;
    item.statusTimeline.push({
      status,
      note: note || `Status updated to ${status}`,
      updatedBy: req.user.name,
      timestamp: new Date(),
    });

    await item.save();

    const io = req.app.get('io');
    if (io) {
      io.emit('emergency_request_updated', item);
      io.emit(`request_status_update_${item.userId}`, {
        requestId: item._id,
        status,
        note,
      });
    }

    res.json({ success: true, message: `Status updated to ${status}`, data: item });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get requests created by logged in citizen
// @route   GET /api/requests/my-requests
// @access  Private
const getMyRequests = async (req, res) => {
  try {
    if (memoryStore.isUsingMemoryStore) {
      const list = memoryStore.helpRequests.filter(
        (r) => r.userId.toString() === req.user._id.toString()
      );
      return res.json({ success: true, count: list.length, data: list });
    }

    const list = await HelpRequest.find({ userId: req.user._id }).sort({ createdAt: -1 });
    res.json({ success: true, count: list.length, data: list });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all requests (Admin or Command Center)
// @route   GET /api/requests
// @access  Private (Admin / Responder)
const getAllRequests = async (req, res) => {
  try {
    const { category, urgency, status } = req.query;

    if (memoryStore.isUsingMemoryStore) {
      let filtered = [...memoryStore.helpRequests];
      if (category) filtered = filtered.filter((r) => r.category === category);
      if (urgency) filtered = filtered.filter((r) => r.urgencyLevel === urgency);
      if (status) filtered = filtered.filter((r) => r.status === status);
      return res.json({ success: true, count: filtered.length, data: filtered });
    }

    const filterObj = {};
    if (category) filterObj.category = category;
    if (urgency) filterObj.urgencyLevel = urgency;
    if (status) filterObj.status = status;

    const list = await HelpRequest.find(filterObj).sort({ createdAt: -1 });
    res.json({ success: true, count: list.length, data: list });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  createHelpRequest,
  getNearbyRequests,
  acceptHelpRequest,
  updateRequestStatus,
  getMyRequests,
  getAllRequests,
};
