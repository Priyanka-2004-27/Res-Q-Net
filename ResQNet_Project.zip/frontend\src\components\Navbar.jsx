import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLocation } from '../context/LocationContext';
import {
  ShieldAlert,
  Radio,
  MapPin,
  Bot,
  UserCheck,
  LogOut,
  AlertOctagon,
  LifeBuoy,
  BookOpen,
  Sliders,
} from 'lucide-react';

export const Navbar = ({ onOpenSos, onOpenAi, onOpenEditProfile, activeTab, setActiveTab }) => {
  const { user, logout, quickLogin, isAuthenticated } = useAuth();
  const { lat, lng, isLocating, fetchCurrentLocation } = useLocation();
  const [showRoleMenu, setShowRoleMenu] = useState(false);

  return (
    <header style={{
      backgroundColor: '#0f172a',
      borderBottom: '1px solid #1e293b',
      position: 'sticky',
      top: 0,
      zIndex: 1000,
    }}>
      <div style={{
        maxWidth: '1440px',
        margin: '0 auto',
        padding: '12px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '12px'
      }}>
        {/* Brand / Logo */}
        <div
          onClick={() => setActiveTab('home')}
          style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' }}
        >
          <div style={{
            position: 'relative',
            width: '40px',
            height: '40px',
            borderRadius: '10px',
            backgroundColor: '#dc2626',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 0 15px rgba(220, 38, 38, 0.5)'
          }}>
            <ShieldAlert size={24} color="#ffffff" />
            <span style={{
              position: 'absolute',
              top: '-2px',
              right: '-2px',
              width: '10px',
              height: '10px',
              backgroundColor: '#10b981',
              borderRadius: '50%',
              border: '2px solid #0f172a'
            }} />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span style={{ fontSize: '20px', fontWeight: '800', letterSpacing: '-0.02em', color: '#f8fafc' }}>
                ResQ<span style={{ color: '#ef4444' }}>Net</span>
              </span>
              <span style={{
                fontSize: '10px',
                padding: '2px 6px',
                borderRadius: '4px',
                backgroundColor: 'rgba(239, 68, 68, 0.2)',
                color: '#f87171',
                fontWeight: '700',
                border: '1px solid rgba(239, 68, 68, 0.4)'
              }}>
                DISASTER ASSIST
              </span>
            </div>
            <p style={{ fontSize: '11px', color: '#94a3b8' }}>Real-time Emergency & Rescue Coordination</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          {[
            { id: 'home', label: 'Live Map & Hub', icon: Radio },
            { id: 'citizen', label: 'Citizen Portal', icon: UserCheck },
            { id: 'helper', label: 'Helper / Volunteer', icon: LifeBuoy },
            { id: 'admin', label: 'Admin Command', icon: Sliders },
            { id: 'guides', label: 'Safety Guides', icon: BookOpen },
          ].map((tab) => {
            const Icon = tab.icon;
            const isTabActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                style={{
                  padding: '8px 14px',
                  borderRadius: '8px',
                  fontSize: '13px',
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  backgroundColor: isTabActive ? '#1e293b' : 'transparent',
                  color: isTabActive ? '#38bdf8' : '#cbd5e1',
                  border: isTabActive ? '1px solid #334155' : '1px solid transparent'
                }}
              >
                <Icon size={16} /> {tab.label}
              </button>
            );
          })}
        </nav>

        {/* Action Controls & User Switcher */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <button
            onClick={fetchCurrentLocation}
            title="Click to refresh GPS location"
            style={{
              padding: '6px 12px',
              borderRadius: '8px',
              fontSize: '12px',
              backgroundColor: '#1e293b',
              border: '1px solid #334155',
              color: '#94a3b8',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            <MapPin size={14} color="#38bdf8" />
            <span>{isLocating ? 'Locating...' : `${lat.toFixed(2)}, ${lng.toFixed(2)}`}</span>
          </button>

          <button
            onClick={onOpenAi}
            style={{
              padding: '8px 14px',
              borderRadius: '8px',
              fontSize: '13px',
              fontWeight: '600',
              backgroundColor: '#4338ca',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              border: '1px solid #6366f1',
              boxShadow: '0 0 10px rgba(99, 102, 241, 0.4)'
            }}
          >
            <Bot size={16} />
            <span>ResQ AI</span>
          </button>

          <button
            onClick={onOpenSos}
            className="sos-glow-button"
            style={{
              padding: '9px 18px',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '800',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              letterSpacing: '0.04em',
              textTransform: 'uppercase'
            }}
          >
            <AlertOctagon size={18} />
            <span>TRIGGER SOS</span>
          </button>

          {/* Quick Role Switcher */}
          <div style={{ position: 'relative' }}>
            <button
              onClick={() => setShowRoleMenu(!showRoleMenu)}
              style={{
                padding: '7px 12px',
                borderRadius: '8px',
                fontSize: '13px',
                backgroundColor: '#1e293b',
                border: '1px solid #334155',
                color: '#f8fafc',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
            >
              <div style={{
                width: '24px',
                height: '24px',
                borderRadius: '50%',
                backgroundColor: user?.role === 'admin' ? '#ef4444' : user?.role === 'volunteer' ? '#10b981' : '#3b82f6',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '11px',
                fontWeight: '700'
              }}>
                {user ? user.name.charAt(0) : '?'}
              </div>
              <span>{user ? user.name.split(' ')[0] : 'Demo Profiles'}</span>
            </button>

            {showRoleMenu && (
              <div
                style={{
                  position: 'absolute',
                  right: 0,
                  top: '110%',
                  width: '260px',
                  backgroundColor: '#111827',
                  border: '1px solid #374151',
                  borderRadius: '12px',
                  boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.7)',
                  padding: '12px',
                  zIndex: 2000,
                }}
              >
                <div style={{ borderBottom: '1px solid #1f2937', paddingBottom: '8px', marginBottom: '8px' }}>
                  <p style={{ fontSize: '11px', textTransform: 'uppercase', color: '#9ca3af', fontWeight: '700', margin: 0 }}>
                    Active User Profile
                  </p>
                  <p style={{ fontSize: '13px', fontWeight: '600', color: '#f9fafb', margin: '2px 0 0' }}>
                    {user ? user.name : 'Guest User'}
                  </p>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '4px' }}>
                    <span style={{ fontSize: '11px', color: '#60a5fa', textTransform: 'uppercase', fontWeight: '700' }}>
                      Role: {user ? user.role : 'None'}
                    </span>
                    <button
                      onClick={() => { onOpenEditProfile(); setShowRoleMenu(false); }}
                      style={{ fontSize: '11px', color: '#38bdf8', padding: '2px 6px', borderRadius: '4px', backgroundColor: '#1e293b', border: '1px solid #334155', cursor: 'pointer' }}
                    >
                      ✏️ Edit Profile
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => { quickLogin('citizen'); setShowRoleMenu(false); }}
                  style={{ width: '100%', textAlign: 'left', padding: '6px 8px', fontSize: '12px', color: '#e5e7eb', borderRadius: '6px', marginBottom: '2px' }}
                >
                  👤 Citizen (Kahan Gandhi)
                </button>
                <button
                  onClick={() => { quickLogin('volunteer'); setShowRoleMenu(false); }}
                  style={{ width: '100%', textAlign: 'left', padding: '6px 8px', fontSize: '12px', color: '#e5e7eb', borderRadius: '6px', marginBottom: '2px' }}
                >
                  🤝 Volunteer (Rahul Sharma)
                </button>
                <button
                  onClick={() => { quickLogin('paramedic'); setShowRoleMenu(false); }}
                  style={{ width: '100%', textAlign: 'left', padding: '6px 8px', fontSize: '12px', color: '#e5e7eb', borderRadius: '6px', marginBottom: '2px' }}
                >
                  🚑 Paramedic (Dr. Priya Patel)
                </button>
                <button
                  onClick={() => { quickLogin('admin'); setShowRoleMenu(false); }}
                  style={{ width: '100%', textAlign: 'left', padding: '6px 8px', fontSize: '12px', color: '#e5e7eb', borderRadius: '6px', marginBottom: '6px' }}
                >
                  🏛️ Admin (Disaster Control HQ)
                </button>

                {isAuthenticated && (
                  <button
                    onClick={() => { logout(); setShowRoleMenu(false); }}
                    style={{ width: '100%', padding: '8px', fontSize: '12px', color: '#f87171', borderRadius: '6px', border: '1px solid #7f1d1d', backgroundColor: 'rgba(239, 68, 68, 0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}
                  >
                    <LogOut size={14} /> Log Out
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
