const mongoose = require('mongoose');

const safetyGuideSchema = new mongoose.Schema(
  {
    category: {
      type: String,
      required: true,
      unique: true,
      enum: [
        'earthquake',
        'flood',
        'cyclone',
        'fire',
        'landslide',
        'chemical_hazard',
        'tsunami',
        'first_aid',
        'heatwave',
      ],
    },
    title: {
      type: String,
      required: true,
    },
    icon: {
      type: String,
      default: 'ShieldAlert',
    },
    summary: {
      type: String,
      required: true,
    },
    beforeEmergency: {
      type: [String],
      default: [],
    },
    duringEmergency: {
      type: [String],
      default: [],
    },
    afterEmergency: {
      type: [String],
      default: [],
    },
    dos: {
      type: [String],
      default: [],
    },
    donts: {
      type: [String],
      default: [],
    },
    emergencyContacts: [
      {
        service: { type: String },
        number: { type: String },
        description: { type: String },
      },
    ],
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('SafetyGuide', safetyGuideSchema);
