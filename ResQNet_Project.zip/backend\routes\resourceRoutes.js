const express = require('express');
const router = express.Router();
const {
  getAllResources,
  getNearbyResources,
  createResource,
  updateResourceOccupancy,
} = require('../controllers/resourceController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.get('/', getAllResources);
router.get('/nearby', getNearbyResources);
router.post('/', protect, authorize('admin', 'responder'), createResource);
router.put('/:id/occupancy', protect, authorize('volunteer', 'responder', 'admin'), updateResourceOccupancy);

module.exports = router;
