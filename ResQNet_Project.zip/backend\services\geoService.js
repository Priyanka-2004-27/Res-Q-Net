/**
 * Geolocation helper utilities for distance calculation and radius matching
 */

// Earth radius in kilometers
const EARTH_RADIUS_KM = 6371;

/**
 * Calculates Haversine distance between two [lng, lat] coordinate pairs in kilometers.
 * @param {[number, number]} coord1 [longitude, latitude]
 * @param {[number, number]} coord2 [longitude, latitude]
 * @returns {number} Distance in kilometers
 */
function calculateDistanceKm(coord1, coord2) {
  if (!coord1 || !coord2 || coord1.length < 2 || coord2.length < 2) return Infinity;

  const [lng1, lat1] = coord1;
  const [lng2, lat2] = coord2;

  const dLat = toRadians(lat2 - lat1);
  const dLng = toRadians(lng2 - lng1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(EARTH_RADIUS_KM * c * 100) / 100; // rounded to 2 decimal places
}

function toRadians(deg) {
  return deg * (Math.PI / 180);
}

/**
 * Estimated response time in minutes based on distance (assuming emergency urban speed ~ 35 km/h)
 */
function estimateEtaMinutes(distanceKm) {
  if (!distanceKm || distanceKm <= 0) return 3;
  const speedKmPerHr = 35;
  const timeHrs = distanceKm / speedKmPerHr;
  const timeMins = Math.ceil(timeHrs * 60) + 3; // +3 minutes dispatch buffer
  return Math.max(timeMins, 2);
}

module.exports = {
  calculateDistanceKm,
  estimateEtaMinutes,
  EARTH_RADIUS_KM,
};
