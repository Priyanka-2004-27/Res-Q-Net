import React, { useState, useEffect } from 'react';
import { useLocation } from '../context/LocationContext';
import api from '../services/api';
import {
  X,
  MapPin,
  HeartPulse,
  Flame,
  Waves,
  Activity,
  AlertOctagon,
  Users,
  Bot,
} from 'lucide-react';

const CATEGORIES = [
  { id: 'flood', label: 'Flash Flood', icon: Waves, color: '#38bdf8' },
  { id: 'earthquake', label: 'Earthquake', icon: Activity, color: '#fb923c' },
  { id: 'fire', label: 'Fire Hazard', icon: Flame, color: '#f87171' },
  { id: 'medical', label: 'Medical Trauma', icon: HeartPulse, color: '#f43f5e' },
  { id: 'rescue_evacuation', label: 'Trapped / Evacuation', icon: Users, color: '#34d399' },
];

export const SosModal = ({ isOpen, onClose, onSosSubmitted }) => {
  const { coords, lat, lng, address } = useLocation();

  const [category, setCategory] = useState('flood');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [casualtiesCount, setCasualtiesCount] = useState(1);
  const [needsMedical, setNeedsMedical] = useState(false);
  const [needsEvacuation, setNeedsEvacuation] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMessage('');

    try {
      const payload = {
        title: title || `${category.toUpperCase()} Emergency`,
        description,
        category,
        location: {
          type: 'Point',
          coordinates: coords,
        },
        address,
        casualtiesCount: Number(casualtiesCount) || 1,
        needsMedical,
        needsEvacuation,
      };

      const res = await api.post('/requests', payload);
      if (res.data.success) {
        setIsSubmitting(false);
        onClose();
        if (onSosSubmitted) onSosSubmitted(res.data.data);
      }
    } catch (err) {
      setErrorMessage(err.response?.data?.message || 'Failed to dispatch SOS alert. Please try again or call 112.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content" style={{ padding: '24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px', borderBottom: '1px solid #1f2937', paddingBottom: '14px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ padding: '8px', borderRadius: '10px', backgroundColor: '#dc2626', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <AlertOctagon size={24} color="#fff" />
            </div>
            <div>
              <h2 style={{ fontSize: '18px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>
                DISPATCH EMERGENCY SOS
              </h2>
              <p style={{ fontSize: '12px', color: '#fca5a5', margin: 0 }}>
                Instant broadcast to nearby volunteers & responders
              </p>
            </div>
          </div>
          <button onClick={onClose} style={{ color: '#9ca3af', padding: '6px' }}>
            <X size={20} />
          </button>
        </div>

        {errorMessage && (
          <div style={{ padding: '10px', borderRadius: '8px', backgroundColor: 'rgba(239, 68, 68, 0.2)', color: '#fca5a5', fontSize: '13px', marginBottom: '14px' }}>
            ⚠️ {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div style={{ backgroundColor: '#0f172a', border: '1px solid #1f2937', borderRadius: '10px', padding: '10px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <MapPin size={18} color="#38bdf8" />
            <div>
              <span style={{ fontSize: '10px', color: '#94a3b8', textTransform: 'uppercase', fontWeight: '700' }}>
                GPS Coordinates
              </span>
              <p style={{ fontSize: '12px', fontWeight: '600', color: '#e2e8f0', margin: 0 }}>
                {address} ({lat.toFixed(4)}, {lng.toFixed(4)})
              </p>
            </div>
          </div>

          <div style={{ marginBottom: '16px' }}>
            <label style={{ display: 'block', fontSize: '11px', textTransform: 'uppercase', color: '#9ca3af', fontWeight: '700', marginBottom: '6px' }}>
              Disaster Type:
            </label>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(110px, 1fr))', gap: '8px' }}>
              {CATEGORIES.map((cat) => {
                const Icon = cat.icon;
                const isSelected = category === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setCategory(cat.id)}
                    style={{
                      padding: '8px',
                      borderRadius: '8px',
                      border: isSelected ? `2px solid ${cat.color}` : '1px solid #374151',
                      backgroundColor: isSelected ? 'rgba(30, 41, 59, 0.9)' : '#0f172a',
                      color: isSelected ? '#ffffff' : '#9ca3af',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: '4px',
                      fontSize: '11px',
                      fontWeight: '600',
                    }}
                  >
                    <Icon size={18} color={cat.color} />
                    <span>{cat.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div style={{ marginBottom: '12px' }}>
            <label style={{ display: 'block', fontSize: '11px', textTransform: 'uppercase', color: '#9ca3af', fontWeight: '700', marginBottom: '4px' }}>
              Emergency Title:
            </label>
            <input
              type="text"
              placeholder="e.g. Rising flood water in ground floor"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>

          <div style={{ marginBottom: '12px' }}>
            <label style={{ display: 'block', fontSize: '11px', textTransform: 'uppercase', color: '#9ca3af', fontWeight: '700', marginBottom: '4px' }}>
              Description & Location Landmark:
            </label>
            <textarea
              rows={2}
              placeholder="Provide exact house number or landmarks..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <div style={{ display: 'flex', gap: '16px', marginBottom: '18px' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#f8fafc' }}>
              <input
                type="checkbox"
                checked={needsMedical}
                onChange={(e) => setNeedsMedical(e.target.checked)}
              />
              Needs Medical Attention (108)
            </label>
            <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#f8fafc' }}>
              <input
                type="checkbox"
                checked={needsEvacuation}
                onChange={(e) => setNeedsEvacuation(e.target.checked)}
              />
              Needs Boat / Evacuation
            </label>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="sos-glow-button"
            style={{
              width: '100%',
              padding: '12px',
              borderRadius: '8px',
              color: '#ffffff',
              fontSize: '14px',
              fontWeight: '800',
              textTransform: 'uppercase',
              cursor: isSubmitting ? 'not-allowed' : 'pointer',
            }}
          >
            {isSubmitting ? 'Broadcasting SOS...' : 'BROADCAST EMERGENCY SOS NOW'}
          </button>
        </form>
      </div>
    </div>
  );
};
