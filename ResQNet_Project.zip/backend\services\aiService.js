/**
 * ResQNet AI Emergency Intelligence Service
 * Handles Automated Incident Triage, Severity Classification, and Interactive Emergency Guidance
 */

// Heuristic emergency rules & protocols
const CATEGORY_PROTOCOLS = {
  flood: {
    baseScore: 7,
    services: ['Water Rescue Team', 'Inflatable Boat Unit', 'Paramedics'],
    actions: [
      'Disconnect main power circuit and LPG gas cylinder immediately if water is rising.',
      'Do not step into swift-moving water or open drainage holes.',
      'Move elderly, children, and pets to upper floors or rooftop.',
      'Wave a brightly colored cloth or flashlight from roof to signal rescue boats.',
    ],
  },
  earthquake: {
    baseScore: 8,
    services: ['Urban Search & Rescue (USAR)', 'Heavy Structural Squad', 'Trauma Unit'],
    actions: [
      'Drop, Cover, and Hold On beneath sturdy furniture; stay away from windows and mirrors.',
      'If trapped under debris, cover nose/mouth with cloth and tap rhythmically on pipes/walls instead of yelling to save energy and oxygen.',
      'Do not light lighters or use open flames due to potential gas leaks.',
      'Avoid elevators; use stairways only after structural checking.',
    ],
  },
  fire: {
    baseScore: 8,
    services: ['Municipal Fire Brigade (101)', 'Burn & Trauma Medical Unit', 'Hazmat Team'],
    actions: [
      'Crawl low under smoke—cleaner air is closest to the floor.',
      'Feel doorknobs with the back of your hand; if hot, do NOT open the door.',
      'Seal door cracks with wet towels or clothes if trapped in a room.',
      'Stop, Drop, and Roll if clothing catches fire.',
    ],
  },
  cyclone: {
    baseScore: 7,
    services: ['Civil Defense', 'NDRF Evacuation Squad', 'Tree Clearing Crew'],
    actions: [
      'Seek refuge in the most interior, windowless room on the lowest floor.',
      'Stay away from glass windows and tin roof sheds.',
      'Keep mobile devices in power-saving mode and prepare emergency go-bag.',
      'Do not venture outside during the eye of the storm (temporary lull).',
    ],
  },
  medical: {
    baseScore: 8,
    services: ['Emergency Ambulance (108)', 'Trauma Paramedic', 'Blood Bank Alert'],
    actions: [
      'Keep patient calm, lying down, and warm to prevent circulatory shock.',
      'For severe bleeding, apply firm, continuous direct pressure with clean cloth.',
      'If victim is unconscious and unresponsive, check breathing and begin chest compressions (100/min).',
      'Do not administer oral food or water if surgery or anesthesia may be required.',
    ],
  },
  building_collapse: {
    baseScore: 9,
    services: ['NDRF Heavy Rescue', 'K9 Search Dogs', 'Hydraulic Jack Team'],
    actions: [
      'Protect vital head and chest areas with arms or nearby cushions.',
      'Conserve your voice—tap rhythmically with stones or metal pipes on concrete.',
      'Avoid unnecessary movements to prevent kicking up choking concrete dust.',
      'Look for stable void spaces created by fallen slabs.',
    ],
  },
  landslide: {
    baseScore: 8,
    services: ['Geological Emergency Response', 'Earthmoving Rescue Squad'],
    actions: [
      'Stay alert for rumbling sounds, crackling trees, or sudden mudflow trickles.',
      'Move quickly out of the direct path of the flow toward higher ground.',
      'Curl into a tight ball and protect your head if escape is no longer possible.',
    ],
  },
  industrial_hazard: {
    baseScore: 8,
    services: ['Hazmat Chemical Squad', 'Decontamination Team', 'Poison Control Center'],
    actions: [
      'Evacuate upwind and uphill from the chemical source.',
      'Cover face with a damp cloth or N95 mask.',
      'Remove contaminated clothing immediately and rinse exposed skin with abundant water.',
    ],
  },
  food_water: {
    baseScore: 5,
    services: ['Relief Supplies Distribution', 'Red Cross Kitchen', 'Water Tanker'],
    actions: [
      'Boil or purify any untreated water before consumption.',
      'Register household count at nearest municipal distribution relief camp.',
      'Prioritize clean hydration for infants, nursing mothers, and elderly members.',
    ],
  },
  rescue_evacuation: {
    baseScore: 8,
    services: ['Rapid Evacuation Taskforce', 'Transport Ambulances', 'Emergency Shelter'],
    actions: [
      'Gather government photo identification, essential prescription medicines, and warm clothing.',
      'Head to designated muster points or follow volunteer instructions.',
      'Keep children and elderly close by holding hands; do not delay for bulky belongings.',
    ],
  },
  other: {
    baseScore: 5,
    services: ['Emergency Volunteer Squad', 'Local Police (112)'],
    actions: [
      'Remain in a safe location and keep phone line open for responder contact.',
      'Share precise landmarks or GPS coordinates with dispatchers.',
      'Follow instructions from verified local authorities.',
    ],
  },
};

/**
 * Perform automated AI Triage on emergency report
 */
function performAiTriage({ category, urgencyLevel, casualtiesCount, needsMedical, needsEvacuation, description }) {
  const protocol = CATEGORY_PROTOCOLS[category] || CATEGORY_PROTOCOLS.other;

  let riskScore = protocol.baseScore;

  // Adjust risk based on casualties
  const casualties = Number(casualtiesCount) || 0;
  if (casualties > 5) riskScore += 2;
  else if (casualties > 0) riskScore += 1;

  // Adjust for critical flags
  if (needsMedical) riskScore += 1;
  if (needsEvacuation) riskScore += 1;
  if (urgencyLevel === 'critical') riskScore += 2;
  else if (urgencyLevel === 'low') riskScore -= 2;

  // Description keyword sentiment check
  const desc = (description || '').toLowerCase();
  if (desc.includes('trapped') || desc.includes('unconscious') || desc.includes('bleeding') || desc.includes('fire') || desc.includes('sink')) {
    riskScore += 1;
  }

  // Bound score between 1 and 10
  riskScore = Math.min(Math.max(riskScore, 1), 10);

  let severityLabel = 'Moderate';
  if (riskScore >= 9) severityLabel = 'CRITICAL: Immediate Threat to Life';
  else if (riskScore >= 7) severityLabel = 'HIGH PRIORITY: Rapid Dispatch Required';
  else if (riskScore >= 5) severityLabel = 'ELEVATED: Prompt Assistance Scheduled';
  else severityLabel = 'STANDARD: Non-life-threatening';

  return {
    riskScore,
    severityLabel,
    immediateActions: protocol.actions,
    recommendedServices: protocol.services,
    generatedAt: new Date(),
  };
}

/**
 * ResQNet Conversational AI Engine
 * Provides instant disaster advisory, safety steps, and situational guidance
 */
async function getAiEmergencyAdvice({ query, disasterType, location, userRole }) {
  const cleanQuery = (query || '').toLowerCase();

  // Keyword-based fast emergency response matrix
  let responseText = '';
  let priorityLevel = 'HIGH';
  let suggestedActions = [];
  let emergencyNumbers = [
    { service: 'Universal Emergency Helpline', number: '112' },
    { service: 'Medical Ambulance', number: '108' },
    { service: 'Disaster Management Helpline', number: '1077' },
    { service: 'Fire Brigade', number: '101' },
  ];

  if (cleanQuery.includes('bleed') || cleanQuery.includes('cut') || cleanQuery.includes('wound')) {
    priorityLevel = 'CRITICAL';
    responseText =
      '⚠️ Immediate Severe Bleeding Protocol: Apply continuous, firm direct pressure over the wound with a clean cloth or sterile gauze. Do NOT lift the cloth to check. Elevate the wounded limb above heart level if no bone fracture is suspected. If bleeding does not stop and is spurting, consider applying an emergency tourniquet 2-3 inches above the wound (never over a joint). Dial 108 immediately.';
    suggestedActions = [
      'Apply direct firm pressure with clean pad',
      'Keep patient warm and still (prevent shock)',
      'Do not remove objects embedded in wound',
      'Call 108 for ambulance dispatch',
    ];
  } else if (cleanQuery.includes('cpr') || cleanQuery.includes('heart') || cleanQuery.includes('unconscious') || cleanQuery.includes('not breathing')) {
    priorityLevel = 'CRITICAL';
    responseText =
      '🚨 CPR Emergency Life Support: 1) Call 108 immediately. 2) Place heel of one hand on the center of the chest, interlock other hand on top. 3) Push hard and fast at 100-120 beats per minute (2 inches deep). Allow chest to recoil fully. 4) If trained, deliver 2 rescue breaths after every 30 compressions; otherwise, perform hands-only CPR non-stop until paramedics arrive.';
    suggestedActions = [
      'Check responsiveness: tap shoulders and shout',
      'Call 108 and get an AED if available',
      'Begin hard and fast chest compressions',
      'Rotate compressor every 2 minutes if tired',
    ];
  } else if (cleanQuery.includes('flood') || cleanQuery.includes('water') || cleanQuery.includes('drown') || cleanQuery.includes('submerged')) {
    priorityLevel = 'HIGH';
    responseText =
      '🌊 Flood Safety Protocol: Disconnect electrical mains and LPG gas immediately. Move upward to higher floors. Never attempt to drive or walk through flowing water—just 6 inches of water can knock an adult down. Stay out of basements. Use ResQNet SOS to broadcast your live GPS coordinates to nearby rescue boats and volunteers.';
    suggestedActions = [
      'Turn off electricity and cooking gas at source',
      'Move to higher elevation / roof if needed',
      'Signal with flashlight or bright cloth',
      'Do not drink untreated tap or flood water',
    ];
  } else if (cleanQuery.includes('earthquake') || cleanQuery.includes('shaking') || cleanQuery.includes('tremor')) {
    priorityLevel = 'HIGH';
    responseText =
      '🏢 Earthquake Response Protocol: DROP to hands and knees. COVER your head and neck under a sturdy desk or table. HOLD ON until shaking ceases. If in bed, hold on and stay there, protecting your head with a pillow. If outdoors, move to an open area clear of buildings, power lines, and trees. Do not use elevators.';
    suggestedActions = [
      'Drop, Cover, and Hold On',
      'Stay away from windows and heavy hanging mirrors',
      'Check for gas leaks and cracks after tremors cease',
      'Prepare for aftershocks',
    ];
  } else if (cleanQuery.includes('fire') || cleanQuery.includes('smoke') || cleanQuery.includes('burn')) {
    priorityLevel = 'CRITICAL';
    responseText =
      '🔥 Fire & Burn Emergency: In smoke, stay low on your hands and knees where air is cooler and cleaner. Test doors with back of hand before opening. If clothes catch fire: STOP, DROP, and ROLL. For skin burns: hold under clean running cool water for 20 minutes (no ice, butter, or ointments). Dial 101 for Fire Rescue.';
    suggestedActions = [
      'Crawl low under smoke to nearest exit',
      'Never use elevators during a fire alarm',
      'Cool thermal burns with running water for 20 mins',
      'Dial 101 Fire Emergency',
    ];
  } else if (cleanQuery.includes('shelter') || cleanQuery.includes('hospital') || cleanQuery.includes('food') || cleanQuery.includes('water') || cleanQuery.includes('resource')) {
    priorityLevel = 'MEDIUM';
    responseText =
      '📍 ResQNet Emergency Map & Resource Locator: You can view open relief camps, trauma hospitals, and food distribution centers directly on the ResQNet interactive map. Shelters are color-coded by capacity and operational status.';
    suggestedActions = [
      'Open the Live Map tab to view verified emergency centers',
      'Check real-time capacity and contact numbers',
      'Use the filter buttons to isolate Hospitals, Shelters, or Fire Stations',
    ];
  } else {
    // General disaster advisory
    responseText = `🛡️ ResQNet Emergency AI Advisory: Stay calm and evaluate your immediate surroundings. Ensure personal physical safety before attempting to assist others. If you or someone nearby is in critical danger, hit the Red "Trigger SOS" button to broadcast your live GPS coordinates to nearby registered volunteers and emergency responders.`;
    suggestedActions = [
      'Trigger Emergency SOS if immediate danger exists',
      'Check the Live Alerts banner for official disaster notices',
      'Locate nearest shelter or hospital on the map',
      'Keep mobile phone battery conserved',
    ];
  }

  return {
    query,
    priorityLevel,
    response: responseText,
    suggestedActions,
    emergencyNumbers,
    timestamp: new Date(),
  };
}

module.exports = {
  performAiTriage,
  getAiEmergencyAdvice,
  CATEGORY_PROTOCOLS,
};
