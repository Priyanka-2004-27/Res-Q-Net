import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useLocation } from '../context/LocationContext';
import { Radio, Building } from 'lucide-react';

export const AdminDashboard = () => {
  const { user } = useAuth();
  const { lat, lng } = useLocation();

  const [requests, setRequests] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [resources, setResources] = useState([]);

  const [alertTitle, setAlertTitle] = useState('');
  const [alertCategory, setAlertCategory] = useState('flood');
  const [alertSeverity, setAlertSeverity] = useState('critical');
  const [alertSummary, setAlertSummary] = useState('');

  const loadData = async () => {
    try {
      const [reqRes, alRes, resRes] = await Promise.all([
        api.get('/requests'),
        api.get('/alerts'),
        api.get('/resources'),
      ]);
      if (reqRes.data.success) setRequests(reqRes.data.data);
      if (alRes.data.success) setAlerts(alRes.data.data);
      if (resRes.data.success) setResources(resRes.data.data);
    } catch (err) {
      console.warn('Admin load:', err.message);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleBroadcast = async (e) => {
    e.preventDefault();
    try {
      await api.post('/alerts', {
        title: alertTitle,
        category: alertCategory,
        severity: alertSeverity,
        summary: alertSummary,
        location: { type: 'Point', coordinates: [lng, lat] },
      });
      alert('Alert broadcasted successfully!');
      setAlertTitle('');
      setAlertSummary('');
      loadData();
    } catch (err) {
      alert('Broadcast failed');
    }
  };

  return (
    <div className="container" style={{ padding: '24px 20px 60px' }}>
      <div style={{ backgroundColor: '#111827', borderRadius: '12px', padding: '20px', marginBottom: '20px' }}>
        <h1 style={{ fontSize: '20px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>
          Admin Command Center
        </h1>
        <p style={{ fontSize: '12px', color: '#94a3b8', margin: '2px 0 0' }}>
          Official Disaster Operations & Broadcast Dispatch
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '20px', marginBottom: '24px' }}>
        {/* Broadcast Form */}
        <div className="resq-card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
            <Radio size={18} color="#ef4444" />
            <h3 style={{ fontSize: '15px', fontWeight: '700', color: '#f8fafc', margin: 0 }}>Broadcast Emergency Warning</h3>
          </div>
          <form onSubmit={handleBroadcast}>
            <div style={{ marginBottom: '8px' }}>
              <input
                type="text"
                placeholder="Alert Title"
                value={alertTitle}
                onChange={(e) => setAlertTitle(e.target.value)}
                required
              />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '8px' }}>
              <select value={alertCategory} onChange={(e) => setAlertCategory(e.target.value)}>
                <option value="flood">Flood</option>
                <option value="cyclone">Cyclone</option>
                <option value="earthquake">Earthquake</option>
                <option value="severe_weather">Severe Weather</option>
              </select>
              <select value={alertSeverity} onChange={(e) => setAlertSeverity(e.target.value)}>
                <option value="critical">Critical (Red)</option>
                <option value="warning">Warning (Orange)</option>
                <option value="watch">Watch (Yellow)</option>
              </select>
            </div>
            <div style={{ marginBottom: '12px' }}>
              <textarea
                rows={2}
                placeholder="Disaster summary & safety instructions..."
                value={alertSummary}
                onChange={(e) => setAlertSummary(e.target.value)}
                required
              />
            </div>
            <button type="submit" className="btn-danger" style={{ width: '100%' }}>
              <Radio size={14} /> Send Official Alert
            </button>
          </form>
        </div>

        {/* Quick Stats */}
        <div className="resq-card">
          <h3 style={{ fontSize: '15px', fontWeight: '700', color: '#f8fafc', marginBottom: '12px' }}>Operational Statistics</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <div style={{ background: '#0f172a', padding: '12px', borderRadius: '8px' }}>
              <span style={{ fontSize: '11px', color: '#94a3b8' }}>Total Incidents</span>
              <p style={{ fontSize: '22px', fontWeight: '800', color: '#f8fafc', margin: '4px 0 0' }}>{requests.length}</p>
            </div>
            <div style={{ background: '#0f172a', padding: '12px', borderRadius: '8px' }}>
              <span style={{ fontSize: '11px', color: '#94a3b8' }}>Active Alerts</span>
              <p style={{ fontSize: '22px', fontWeight: '800', color: '#ef4444', margin: '4px 0 0' }}>{alerts.length}</p>
            </div>
            <div style={{ background: '#0f172a', padding: '12px', borderRadius: '8px' }}>
              <span style={{ fontSize: '11px', color: '#94a3b8' }}>Verified Shelters</span>
              <p style={{ fontSize: '22px', fontWeight: '800', color: '#10b981', margin: '4px 0 0' }}>{resources.length}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
