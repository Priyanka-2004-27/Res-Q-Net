const { performAiTriage, getAiEmergencyAdvice } = require('../services/aiService');
const SafetyGuide = require('../models/SafetyGuide');
const { memoryStore } = require('../config/db');

// @desc    ResQ AI Emergency Assistant Chatbot Endpoint
// @route   POST /api/ai/assistant
// @access  Public
const askEmergencyAssistant = async (req, res) => {
  try {
    const { query, disasterType, location } = req.body;

    if (!query) {
      return res.status(400).json({ success: false, message: 'Please provide an emergency query or question' });
    }

    const advice = await getAiEmergencyAdvice({
      query,
      disasterType,
      location,
      userRole: req.user ? req.user.role : 'citizen',
    });

    res.json({ success: true, data: advice });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Perform on-demand incident AI Triage evaluation
// @route   POST /api/ai/triage
// @access  Public
const evaluateIncidentTriage = async (req, res) => {
  try {
    const { category, urgencyLevel, casualtiesCount, needsMedical, needsEvacuation, description } = req.body;

    const triage = performAiTriage({
      category: category || 'medical',
      urgencyLevel: urgencyLevel || 'high',
      casualtiesCount: casualtiesCount || 1,
      needsMedical: !!needsMedical,
      needsEvacuation: !!needsEvacuation,
      description: description || '',
    });

    res.json({ success: true, data: triage });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all safety guides and emergency checklists
// @route   GET /api/ai/safety-guides
// @access  Public
const getSafetyGuides = async (req, res) => {
  try {
    if (memoryStore.isUsingMemoryStore) {
      return res.json({
        success: true,
        count: memoryStore.safetyGuides.length,
        data: memoryStore.safetyGuides,
      });
    }

    const guides = await SafetyGuide.find();
    res.json({ success: true, count: guides.length, data: guides });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  askEmergencyAssistant,
  evaluateIncidentTriage,
  getSafetyGuides,
};
