const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { memoryStore } = require('../config/db');

const JWT_SECRET = process.env.JWT_SECRET || 'resqnet_super_secret_jwt_key_2026';

const protect = async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      token = req.headers.authorization.split(' ')[1];
      const decoded = jwt.verify(token, JWT_SECRET);

      if (memoryStore.isUsingMemoryStore) {
        const found = memoryStore.users.find((u) => u._id.toString() === decoded.id.toString());
        if (!found) {
          return res.status(401).json({ success: false, message: 'User not found in session' });
        }
        req.user = found;
      } else {
        req.user = await User.findById(decoded.id).select('-password');
        if (!req.user) {
          return res.status(401).json({ success: false, message: 'User not found' });
        }
      }

      return next();
    } catch (err) {
      console.error('JWT verification error:', err.message);
      return res.status(401).json({ success: false, message: 'Not authorized, token failed' });
    }
  }

  if (!token) {
    return res.status(401).json({ success: false, message: 'Not authorized, no token provided' });
  }
};

const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Role '${req.user ? req.user.role : 'anonymous'}' is not authorized to access this resource`,
      });
    }
    next();
  };
};

module.exports = {
  protect,
  authorize,
  JWT_SECRET,
};
