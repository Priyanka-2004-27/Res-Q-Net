const mongoose = require('mongoose');

const alertSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Alert title is required'],
      trim: true,
    },
    category: {
      type: String,
      required: true,
      enum: [
        'flood',
        'earthquake',
        'cyclone',
        'wildfire',
        'severe_weather',
        'tsunami',
        'landslide',
        'chemical_hazard',
        'evacuation_notice',
        'all_clear',
      ],
      default: 'severe_weather',
    },
    severity: {
      type: String,
      required: true,
      enum: ['critical', 'warning', 'watch', 'advisory'],
      default: 'warning',
    },
    summary: {
      type: String,
      required: true,
    },
    instructions: {
      type: [String],
      default: [],
    },
    location: {
      type: {
        type: String,
        enum: ['Point'],
        default: 'Point',
      },
      coordinates: {
        type: [Number], // [longitude, latitude]
        required: true,
        default: [72.5714, 23.0225],
      },
    },
    radiusKm: {
      type: Number,
      default: 25, // affected radius in km
    },
    affectedAreaName: {
      type: String,
      default: 'Citywide Alert Zone',
    },
    sourceAuthority: {
      type: String,
      default: 'National Disaster Management Authority (NDMA)',
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    issuedAt: {
      type: Date,
      default: Date.now,
    },
    expiresAt: {
      type: Date,
      default: () => new Date(+new Date() + 24 * 60 * 60 * 1000), // Default 24 hrs
    },
  },
  {
    timestamps: true,
  }
);

alertSchema.index({ location: '2dsphere' });
alertSchema.index({ isActive: 1 });
alertSchema.index({ severity: 1 });

module.exports = mongoose.model('Alert', alertSchema);
