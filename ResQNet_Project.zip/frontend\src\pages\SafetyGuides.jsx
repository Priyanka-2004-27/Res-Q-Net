import React, { useState, useEffect } from 'react';
import api from '../services/api';
import {
  BookOpen,
  CheckCircle2,
  XCircle,
  Activity,
  Waves,
  Flame,
  HeartPulse,
  Wind,
  Sun,
  ShieldAlert,
  AlertTriangle,
  Search,
  PhoneCall,
  CheckSquare,
  Square,
  ArrowRight,
} from 'lucide-react';

export const SafetyGuides = () => {
  const [guides, setGuides] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('earthquake');
  const [searchQuery, setSearchQuery] = useState('');
  const [activePhase, setActivePhase] = useState('all'); // 'all', 'before', 'during', 'after'
  const [checklist, setChecklist] = useState({
    water: false,
    food: false,
    firstAid: false,
    torch: false,
    docs: false,
    powerBank: false,
    whistle: false,
    medicines: false,
  });

  const toggleCheck = (item) => {
    setChecklist((prev) => ({ ...prev, [item]: !prev[item] }));
  };

  useEffect(() => {
    const fetchGuides = async () => {
      try {
        const res = await api.get('/ai/safety-guides');
        if (res.data.success) {
          setGuides(res.data.data);
          if (res.data.data.length > 0) setSelectedCategory(res.data.data[0].category);
        }
      } catch (err) {
        console.warn('Guides err:', err.message);
      }
    };
    fetchGuides();
  }, []);

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'earthquake':
        return <Activity size={16} />;
      case 'flood':
        return <Waves size={16} />;
      case 'cyclone':
        return <Wind size={16} />;
      case 'first_aid':
        return <HeartPulse size={16} />;
      case 'fire':
        return <Flame size={16} />;
      case 'landslide':
        return <AlertTriangle size={16} />;
      case 'chemical_hazard':
        return <ShieldAlert size={16} />;
      case 'tsunami':
        return <Waves size={16} />;
      case 'heatwave':
        return <Sun size={16} />;
      default:
        return <BookOpen size={16} />;
    }
  };

  const filteredGuides = guides.filter((g) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      g.title.toLowerCase().includes(q) ||
      g.summary.toLowerCase().includes(q) ||
      g.category.toLowerCase().includes(q) ||
      (g.dos && g.dos.some((d) => d.toLowerCase().includes(q))) ||
      (g.donts && g.donts.some((d) => d.toLowerCase().includes(q)))
    );
  });

  const currentGuide = guides.find((g) => g.category === selectedCategory) || filteredGuides[0] || guides[0];

  const completedItemsCount = Object.values(checklist).filter(Boolean).length;
  const totalItemsCount = Object.keys(checklist).length;

  return (
    <div className="container" style={{ padding: '28px 20px 80px' }}>
      {/* Page Header */}
      <div style={{ textAlign: 'center', marginBottom: '28px' }}>
        <div style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '6px',
          padding: '4px 12px',
          borderRadius: '9999px',
          backgroundColor: 'rgba(59, 130, 246, 0.15)',
          color: '#60a5fa',
          fontSize: '11px',
          fontWeight: '700',
          marginBottom: '8px',
          border: '1px solid rgba(59, 130, 246, 0.3)',
        }}>
          <BookOpen size={13} /> NDMA & CIVIL DEFENSE PROTOCOLS
        </div>
        <h1 style={{ fontSize: '28px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>
          All Disaster Categories & Survival Protocols
        </h1>
        <p style={{ fontSize: '14px', color: '#94a3b8', marginTop: '6px', maxWidth: '650px', margin: '6px auto 0' }}>
          Step-by-step verified action manuals covering preparation, active crisis response, critical Do's & Don'ts, and official emergency hotlines.
        </p>
      </div>

      {/* Search & Filter Bar */}
      <div style={{ maxWidth: '680px', margin: '0 auto 24px', display: 'flex', gap: '10px' }}>
        <div style={{ position: 'relative', flex: 1 }}>
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#64748b' }} />
          <input
            type="text"
            placeholder="Search safety guides (e.g. water, gas leak, bleeding, CPR, fire)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{ paddingLeft: '38px', backgroundColor: '#111827', borderColor: '#334155' }}
          />
        </div>
      </div>

      {/* All Categories Pills */}
      <div style={{
        display: 'flex',
        gap: '8px',
        justifyContent: 'center',
        flexWrap: 'wrap',
        marginBottom: '28px',
      }}>
        {filteredGuides.map((g) => {
          const isSelected = selectedCategory === g.category;
          return (
            <button
              key={g.category}
              onClick={() => setSelectedCategory(g.category)}
              style={{
                padding: '9px 16px',
                borderRadius: '10px',
                backgroundColor: isSelected ? '#2563eb' : '#1e293b',
                color: isSelected ? '#ffffff' : '#cbd5e1',
                fontSize: '12px',
                fontWeight: '700',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                border: isSelected ? '1px solid #3b82f6' : '1px solid #334155',
                cursor: 'pointer',
                transition: 'all 0.15s ease',
                boxShadow: isSelected ? '0 0 12px rgba(37, 99, 235, 0.4)' : 'none',
              }}
            >
              {getCategoryIcon(g.category)}
              <span>{g.title.replace(' Survival Protocol', '').replace(' Survival Guide', '').replace(' Preparedness', '')}</span>
            </button>
          );
        })}
      </div>

      {currentGuide && (
        <div style={{ maxWidth: '1080px', margin: '0 auto' }}>
          {/* Active Guide Overview Card */}
          <div className="resq-card" style={{ marginBottom: '24px', backgroundColor: '#111827', border: '1px solid #1e293b' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '12px' }}>
              <div>
                <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '3px 8px', borderRadius: '4px', backgroundColor: '#1e293b', color: '#38bdf8', fontSize: '11px', fontWeight: '800', textTransform: 'uppercase', marginBottom: '8px' }}>
                  {getCategoryIcon(currentGuide.category)} Category: {currentGuide.category.replace('_', ' ')}
                </div>
                <h2 style={{ fontSize: '22px', fontWeight: '800', color: '#f8fafc', margin: '0 0 8px' }}>
                  {currentGuide.title}
                </h2>
                <p style={{ fontSize: '14px', color: '#cbd5e1', margin: 0, lineHeight: 1.6 }}>
                  {currentGuide.summary}
                </p>
              </div>

              {/* Emergency Contacts Box */}
              {currentGuide.emergencyContacts && currentGuide.emergencyContacts.length > 0 && (
                <div style={{ background: '#1e293b', border: '1px solid #334155', borderRadius: '10px', padding: '12px 16px', minWidth: '240px' }}>
                  <span style={{ fontSize: '11px', fontWeight: '800', color: '#f87171', textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: '4px', marginBottom: '8px' }}>
                    <PhoneCall size={12} /> Emergency Speed-Dials
                  </span>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                    {currentGuide.emergencyContacts.map((c, i) => (
                      <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '12px' }}>
                        <span style={{ color: '#94a3b8' }}>{c.service}:</span>
                        <a
                          href={`tel:${c.number}`}
                          style={{ color: '#38bdf8', fontWeight: '800', textDecoration: 'none', background: '#0f172a', padding: '2px 8px', borderRadius: '4px', border: '1px solid #334155' }}
                        >
                          {c.number}
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Phase Selector Tabs */}
            <div style={{ display: 'flex', gap: '8px', borderTop: '1px solid #1e293b', marginTop: '20px', paddingTop: '16px', flexWrap: 'wrap' }}>
              {[
                { id: 'all', label: 'All Action Phases' },
                { id: 'before', label: '1. Before Disaster (Prepare)' },
                { id: 'during', label: '2. During Crisis (Survive)' },
                { id: 'after', label: '3. After Calamity (Recover)' },
              ].map((phase) => (
                <button
                  key={phase.id}
                  onClick={() => setActivePhase(phase.id)}
                  style={{
                    padding: '6px 14px',
                    borderRadius: '6px',
                    fontSize: '12px',
                    fontWeight: '700',
                    backgroundColor: activePhase === phase.id ? '#334155' : 'transparent',
                    color: activePhase === phase.id ? '#f8fafc' : '#94a3b8',
                    border: '1px solid #334155',
                    cursor: 'pointer',
                  }}
                >
                  {phase.label}
                </button>
              ))}
            </div>
          </div>

          {/* Action Phases Columns */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '18px', marginBottom: '24px' }}>
            {(activePhase === 'all' || activePhase === 'before') && currentGuide.beforeEmergency && (
              <div className="resq-card" style={{ borderLeft: '4px solid #3b82f6' }}>
                <span style={{ fontSize: '11px', fontWeight: '800', color: '#60a5fa', textTransform: 'uppercase' }}>PHASE 1</span>
                <h3 style={{ fontSize: '16px', fontWeight: '800', color: '#f8fafc', margin: '4px 0 12px' }}>
                  Preparation (Before)
                </h3>
                <ul style={{ paddingLeft: '18px', fontSize: '13px', color: '#cbd5e1', lineHeight: 1.7 }}>
                  {currentGuide.beforeEmergency.map((step, i) => (
                    <li key={i} style={{ marginBottom: '8px' }}>{step}</li>
                  ))}
                </ul>
              </div>
            )}

            {(activePhase === 'all' || activePhase === 'during') && currentGuide.duringEmergency && (
              <div className="resq-card" style={{ borderLeft: '4px solid #f59e0b' }}>
                <span style={{ fontSize: '11px', fontWeight: '800', color: '#fbbf24', textTransform: 'uppercase' }}>PHASE 2</span>
                <h3 style={{ fontSize: '16px', fontWeight: '800', color: '#f8fafc', margin: '4px 0 12px' }}>
                  Active Crisis (During)
                </h3>
                <ul style={{ paddingLeft: '18px', fontSize: '13px', color: '#cbd5e1', lineHeight: 1.7 }}>
                  {currentGuide.duringEmergency.map((step, i) => (
                    <li key={i} style={{ marginBottom: '8px' }}>{step}</li>
                  ))}
                </ul>
              </div>
            )}

            {(activePhase === 'all' || activePhase === 'after') && currentGuide.afterEmergency && (
              <div className="resq-card" style={{ borderLeft: '4px solid #10b981' }}>
                <span style={{ fontSize: '11px', fontWeight: '800', color: '#34d399', textTransform: 'uppercase' }}>PHASE 3</span>
                <h3 style={{ fontSize: '16px', fontWeight: '800', color: '#f8fafc', margin: '4px 0 12px' }}>
                  Recovery & Safety (After)
                </h3>
                <ul style={{ paddingLeft: '18px', fontSize: '13px', color: '#cbd5e1', lineHeight: 1.7 }}>
                  {currentGuide.afterEmergency.map((step, i) => (
                    <li key={i} style={{ marginBottom: '8px' }}>{step}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* DO'S & DON'TS MATRIX */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '20px', marginBottom: '32px' }}>
            <div className="resq-card" style={{ borderTop: '4px solid #10b981', backgroundColor: '#0c1a14' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
                <CheckCircle2 size={20} color="#10b981" />
                <h3 style={{ fontSize: '16px', fontWeight: '800', color: '#34d399', margin: 0 }}>
                  CRITICAL DO'S (जीवन रक्षक नियम)
                </h3>
              </div>
              <ul style={{ paddingLeft: '18px', fontSize: '13px', color: '#d1fae5', margin: 0, lineHeight: 1.7 }}>
                {currentGuide.dos?.map((d, i) => (
                  <li key={i} style={{ marginBottom: '8px' }}>{d}</li>
                ))}
              </ul>
            </div>

            <div className="resq-card" style={{ borderTop: '4px solid #ef4444', backgroundColor: '#1a0c0c' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
                <XCircle size={20} color="#ef4444" />
                <h3 style={{ fontSize: '16px', fontWeight: '800', color: '#f87171', margin: 0 }}>
                  FATAL DON'TS (खतरनाक गलतियाँ)
                </h3>
              </div>
              <ul style={{ paddingLeft: '18px', fontSize: '13px', color: '#fee2e2', margin: 0, lineHeight: 1.7 }}>
                {currentGuide.donts?.map((d, i) => (
                  <li key={i} style={{ marginBottom: '8px' }}>{d}</li>
                ))}
              </ul>
            </div>
          </div>

          {/* 72-Hour Emergency Go-Bag Interactive Checklist */}
          <div className="resq-card" style={{ backgroundColor: '#111827', border: '1px solid #334155' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px', marginBottom: '16px' }}>
              <div>
                <h3 style={{ fontSize: '16px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>
                  🎒 72-Hour Survival Go-Bag Checklist
                </h3>
                <p style={{ fontSize: '12px', color: '#94a3b8', margin: '4px 0 0' }}>
                  Essential items every household must have packed in a waterproof backpack before an evacuation order.
                </p>
              </div>
              <div style={{
                padding: '6px 12px',
                borderRadius: '8px',
                backgroundColor: completedItemsCount === totalItemsCount ? 'rgba(16, 185, 129, 0.2)' : '#1e293b',
                color: completedItemsCount === totalItemsCount ? '#34d399' : '#38bdf8',
                fontSize: '12px',
                fontWeight: '700',
                border: '1px solid #334155',
              }}>
                Ready: {completedItemsCount} / {totalItemsCount} ({Math.round((completedItemsCount / totalItemsCount) * 100)}%)
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '10px' }}>
              {[
                { key: 'water', label: 'Potable Water (3L / person / day)' },
                { key: 'food', label: 'Non-perishable energy bars & ration' },
                { key: 'firstAid', label: 'First Aid Kit, bandages & antiseptic' },
                { key: 'torch', label: 'LED Flashlight & spare batteries' },
                { key: 'docs', label: 'Waterproof pouch with IDs & Deeds' },
                { key: 'powerBank', label: 'High capacity power bank + cables' },
                { key: 'whistle', label: 'Emergency whistle & signaling mirror' },
                { key: 'medicines', label: 'Personal prescription medication' },
              ].map((item) => {
                const isChecked = checklist[item.key];
                return (
                  <div
                    key={item.key}
                    onClick={() => toggleCheck(item.key)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      padding: '10px 12px',
                      borderRadius: '8px',
                      backgroundColor: isChecked ? 'rgba(16, 185, 129, 0.1)' : '#1e293b',
                      border: isChecked ? '1px solid rgba(16, 185, 129, 0.4)' : '1px solid #334155',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease',
                    }}
                  >
                    {isChecked ? <CheckSquare size={16} color="#10b981" /> : <Square size={16} color="#64748b" />}
                    <span style={{ fontSize: '12px', color: isChecked ? '#f8fafc' : '#cbd5e1', textDecoration: isChecked ? 'line-through' : 'none' }}>
                      {item.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
