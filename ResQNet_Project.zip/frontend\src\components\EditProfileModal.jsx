import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { User, Phone, MapPin, Heart, Shield, X, Save, Edit3 } from 'lucide-react';

export const EditProfileModal = ({ isOpen, onClose }) => {
  const { user, login } = useAuth();

  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [address, setAddress] = useState(user?.address || '');
  const [bloodGroup, setBloodGroup] = useState(user?.bloodGroup || 'O+');
  const [skills, setSkills] = useState(
    Array.isArray(user?.volunteerSkills) ? user.volunteerSkills.join(', ') : user?.volunteerSkills || ''
  );
  const [medicalNotes, setMedicalNotes] = useState(user?.medicalNotes || '');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setPhone(user.phone || '');
      setAddress(user.address || '');
      setBloodGroup(user.bloodGroup || 'O+');
      setSkills(Array.isArray(user.volunteerSkills) ? user.volunteerSkills.join(', ') : user.volunteerSkills || '');
      setMedicalNotes(user.medicalNotes || '');
    }
  }, [user, isOpen]);

  if (!isOpen) return null;

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setMessage('');

    try {
      const res = await api.put('/auth/profile', {
        name,
        phone,
        address,
        bloodGroup,
        volunteerSkills: skills,
        medicalNotes,
      });

      if (res.data.success) {
        setMessage('✅ Profile updated successfully!');
        setTimeout(() => {
          window.location.reload(); // Refresh to reflect updated profile across all components
        }, 600);
      }
    } catch (err) {
      setMessage('❌ Update failed. ' + (err.response?.data?.message || err.message));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content" style={{ maxWidth: '540px', padding: '24px' }}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px', borderBottom: '1px solid #1f2937', paddingBottom: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ padding: '8px', borderRadius: '10px', backgroundColor: '#2563eb', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Edit3 size={20} color="#fff" />
            </div>
            <div>
              <h2 style={{ fontSize: '18px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>
                Edit Profile & System Details
              </h2>
              <p style={{ fontSize: '12px', color: '#94a3b8', margin: 0 }}>
                Update your details directly on the live website
              </p>
            </div>
          </div>
          <button onClick={onClose} style={{ color: '#9ca3af', padding: '6px' }}>
            <X size={20} />
          </button>
        </div>

        {message && (
          <div style={{ padding: '10px 14px', borderRadius: '8px', backgroundColor: message.startsWith('✅') ? 'rgba(16, 185, 129, 0.2)' : 'rgba(239, 68, 68, 0.2)', border: message.startsWith('✅') ? '1px solid #10b981' : '1px solid #ef4444', color: '#f8fafc', fontSize: '13px', marginBottom: '16px' }}>
            {message}
          </div>
        )}

        <form onSubmit={handleSave}>
          <div style={{ marginBottom: '12px' }}>
            <label style={{ display: 'block', fontSize: '11px', textTransform: 'uppercase', color: '#9ca3af', fontWeight: '700', marginBottom: '4px' }}>
              Full Name:
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Kahan Gandhi"
              required
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
            <div>
              <label style={{ display: 'block', fontSize: '11px', textTransform: 'uppercase', color: '#9ca3af', fontWeight: '700', marginBottom: '4px' }}>
                Contact Phone:
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98765 43210"
                required
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '11px', textTransform: 'uppercase', color: '#9ca3af', fontWeight: '700', marginBottom: '4px' }}>
                Blood Group:
              </label>
              <select value={bloodGroup} onChange={(e) => setBloodGroup(e.target.value)}>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                <option value="Unknown">Unknown</option>
              </select>
            </div>
          </div>

          <div style={{ marginBottom: '12px' }}>
            <label style={{ display: 'block', fontSize: '11px', textTransform: 'uppercase', color: '#9ca3af', fontWeight: '700', marginBottom: '4px' }}>
              Address / Locality:
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="e.g. Vastrapur, Ahmedabad, Gujarat"
            />
          </div>

          {user?.role === 'volunteer' && (
            <div style={{ marginBottom: '12px' }}>
              <label style={{ display: 'block', fontSize: '11px', textTransform: 'uppercase', color: '#9ca3af', fontWeight: '700', marginBottom: '4px' }}>
                Volunteer Certified Skills (Comma-separated):
              </label>
              <input
                type="text"
                value={skills}
                onChange={(e) => setSkills(e.target.value)}
                placeholder="First Aid, Search & Rescue, CPR, Boat Handling"
              />
            </div>
          )}

          <div style={{ marginBottom: '18px' }}>
            <label style={{ display: 'block', fontSize: '11px', textTransform: 'uppercase', color: '#9ca3af', fontWeight: '700', marginBottom: '4px' }}>
              Medical Notes / Health Conditions:
            </label>
            <input
              type="text"
              value={medicalNotes}
              onChange={(e) => setMedicalNotes(e.target.value)}
              placeholder="e.g. Asthmatic, Diabetic, Allergy to Penicillin"
            />
          </div>

          <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
            <button
              type="button"
              onClick={onClose}
              style={{ padding: '10px 16px', borderRadius: '8px', border: '1px solid #475569', color: '#cbd5e1', fontSize: '13px', fontWeight: '600' }}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="btn-primary"
              style={{ padding: '10px 20px', fontSize: '13px', fontWeight: '700' }}
            >
              <Save size={16} />
              <span>{saving ? 'Saving...' : 'Save Changes'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
