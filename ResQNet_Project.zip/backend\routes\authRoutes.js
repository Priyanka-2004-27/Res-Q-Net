const express = require('express');
const router = express.Router();
const {
  registerUser,
  loginUser,
  getUserProfile,
  updateUserProfile,
  updateLocation,
  toggleAvailability,
  getAllUsers,
} = require('../controllers/authController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.post('/register', registerUser);
router.post('/login', loginUser);
router.get('/me', protect, getUserProfile);
router.put('/profile', protect, updateUserProfile);
router.put('/location', protect, updateLocation);
router.put('/toggle-availability', protect, authorize('volunteer', 'responder', 'admin'), toggleAvailability);
router.get('/users', protect, authorize('admin'), getAllUsers);

module.exports = router;
