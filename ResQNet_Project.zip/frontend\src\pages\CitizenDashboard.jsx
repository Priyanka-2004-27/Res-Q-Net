import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { AlertTriangle, PhoneCall, CheckCircle, Bot } from 'lucide-react';

export const CitizenDashboard = ({ onOpenSos, onOpenAi }) => {
  const { user } = useAuth();
  const [myRequests, setMyRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchMyRequests = async () => {
    try {
      const res = await api.get('/requests/my-requests');
      if (res.data.success) {
        setMyRequests(res.data.data);
      }
    } catch (err) {
      console.warn('Citizen reqs:', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMyRequests();
    const interval = setInterval(fetchMyRequests, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleResolve = async (requestId) => {
    try {
      await api.put(`/requests/${requestId}/status`, { status: 'resolved', note: 'Resolved by citizen.' });
      fetchMyRequests();
    } catch (err) {
      alert('Update failed');
    }
  };

  return (
    <div className="container" style={{ padding: '24px 20px 60px' }}>
      <div style={{ backgroundColor: '#111827', borderRadius: '12px', padding: '20px', marginBottom: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h1 style={{ fontSize: '20px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>
            Citizen Portal: {user?.name || 'Kahan Gandhi'}
          </h1>
          <p style={{ fontSize: '12px', color: '#94a3b8', margin: '2px 0 0' }}>
            Blood Group: {user?.bloodGroup || 'O+'} | Phone: {user?.phone || '+91 9723456789'}
          </p>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button onClick={onOpenAi} style={{ padding: '8px 14px', borderRadius: '6px', backgroundColor: '#1e293b', border: '1px solid #4338ca', color: '#818cf8', fontSize: '12px', fontWeight: '700' }}>
            <Bot size={14} /> ResQ AI
          </button>
          <button onClick={onOpenSos} className="sos-glow-button" style={{ padding: '8px 16px', borderRadius: '6px', color: '#fff', fontSize: '13px', fontWeight: '800' }}>
            <AlertTriangle size={16} /> TRIGGER SOS
          </button>
        </div>
      </div>

      <h2 style={{ fontSize: '16px', fontWeight: '800', color: '#f8fafc', marginBottom: '12px' }}>
        My Active SOS Requests
      </h2>

      {myRequests.length === 0 ? (
        <div className="resq-card" style={{ textAlign: 'center', padding: '40px' }}>
          <CheckCircle size={36} color="#10b981" style={{ margin: '0 auto 8px' }} />
          <p style={{ fontSize: '14px', color: '#f8fafc', fontWeight: '600', margin: 0 }}>No Active Emergencies</p>
          <p style={{ fontSize: '12px', color: '#94a3b8' }}>You are safe. Trigger an SOS whenever needed.</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          {myRequests.map((req) => (
            <div key={req._id} className="resq-card" style={{ borderLeft: '4px solid #ef4444' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <span className="badge badge-critical">{req.urgencyLevel} SOS</span>
                <span style={{ fontSize: '11px', color: '#34d399', fontWeight: '700', textTransform: 'uppercase' }}>
                  Status: {req.status}
                </span>
              </div>
              <h3 style={{ fontSize: '15px', fontWeight: '700', color: '#f8fafc', margin: '0 0 4px' }}>{req.title}</h3>
              <p style={{ fontSize: '12px', color: '#cbd5e1', margin: '0 0 10px' }}>{req.description}</p>

              {req.assignedHelper?.helperName && (
                <div style={{ backgroundColor: 'rgba(16, 185, 129, 0.15)', padding: '10px', borderRadius: '8px', marginBottom: '10px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <span style={{ fontSize: '10px', color: '#34d399', fontWeight: '800', textTransform: 'uppercase' }}>Assigned Helper</span>
                    <p style={{ fontSize: '13px', fontWeight: '700', color: '#f8fafc', margin: 0 }}>{req.assignedHelper.helperName}</p>
                  </div>
                  <a href={`tel:${req.assignedHelper.helperPhone}`} style={{ padding: '6px 12px', backgroundColor: '#10b981', color: '#fff', borderRadius: '6px', fontSize: '11px', fontWeight: '700', textDecoration: 'none' }}>
                    <PhoneCall size={12} /> Call Helper
                  </a>
                </div>
              )}

              {req.status !== 'resolved' && (
                <button onClick={() => handleResolve(req._id)} style={{ padding: '6px 12px', backgroundColor: '#2563eb', color: '#fff', borderRadius: '6px', fontSize: '11px', fontWeight: '700' }}>
                  ✓ Mark Safe & Resolved
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
