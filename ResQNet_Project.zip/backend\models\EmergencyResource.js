const mongoose = require('mongoose');

const emergencyResourceSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Resource name is required'],
      trim: true,
    },
    type: {
      type: String,
      required: true,
      enum: [
        'hospital',
        'shelter',
        'evacuation_center',
        'fire_station',
        'police_station',
        'relief_camp',
        'food_distribution',
        'blood_bank',
      ],
      default: 'shelter',
    },
    location: {
      type: {
        type: String,
        enum: ['Point'],
        default: 'Point',
      },
      coordinates: {
        type: [Number], // [longitude, latitude]
        required: true,
      },
    },
    address: {
      type: String,
      required: true,
    },
    contactPhone: {
      type: String,
      required: true,
    },
    alternatePhone: {
      type: String,
      default: '',
    },
    capacity: {
      type: Number,
      default: 100,
    },
    currentOccupancy: {
      type: Number,
      default: 0,
    },
    availableSupplies: {
      type: [String],
      default: ['Drinking Water', 'First Aid', 'Power Generator'],
    },
    operationalStatus: {
      type: String,
      enum: ['operational', 'near_capacity', 'full', 'evacuated', 'closed'],
      default: 'operational',
    },
    isVerified: {
      type: Boolean,
      default: true,
    },
    notes: {
      type: String,
      default: '',
    },
  },
  {
    timestamps: true,
  }
);

emergencyResourceSchema.index({ location: '2dsphere' });
emergencyResourceSchema.index({ type: 1 });
emergencyResourceSchema.index({ operationalStatus: 1 });

module.exports = mongoose.model('EmergencyResource', emergencyResourceSchema);
