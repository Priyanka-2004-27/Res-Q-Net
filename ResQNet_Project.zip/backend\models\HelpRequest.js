const mongoose = require('mongoose');

const helpRequestSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    userName: {
      type: String,
      required: true,
    },
    userPhone: {
      type: String,
      required: true,
    },
    title: {
      type: String,
      required: [true, 'Please provide an emergency title or brief description'],
      trim: true,
    },
    description: {
      type: String,
      default: '',
    },
    category: {
      type: String,
      required: true,
      enum: [
        'flood',
        'earthquake',
        'fire',
        'cyclone',
        'medical',
        'landslide',
        'building_collapse',
        'industrial_hazard',
        'food_water',
        'rescue_evacuation',
        'other',
      ],
      default: 'medical',
    },
    urgencyLevel: {
      type: String,
      enum: ['critical', 'high', 'medium', 'low'],
      default: 'high',
    },
    location: {
      type: {
        type: String,
        enum: ['Point'],
        default: 'Point',
      },
      coordinates: {
        type: [Number], // [longitude, latitude]
        required: true,
      },
    },
    address: {
      type: String,
      default: 'Coordinates provided via GPS',
    },
    casualtiesCount: {
      type: Number,
      default: 1,
    },
    needsMedical: {
      type: Boolean,
      default: false,
    },
    needsFoodWater: {
      type: Boolean,
      default: false,
    },
    needsEvacuation: {
      type: Boolean,
      default: false,
    },
    specialAssistance: {
      type: String,
      default: '', // e.g. "elderly person, wheelchair needed"
    },
    status: {
      type: String,
      enum: ['pending', 'assigned', 'in_progress', 'resolved', 'cancelled'],
      default: 'pending',
    },
    assignedHelper: {
      helperId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        default: null,
      },
      helperName: { type: String, default: null },
      helperPhone: { type: String, default: null },
      assignedAt: { type: Date, default: null },
      estimatedArrivalMinutes: { type: Number, default: null },
      currentLocation: {
        type: { type: String, enum: ['Point'], default: 'Point' },
        coordinates: { type: [Number], default: [72.5714, 23.0225] },
      },
    },
    statusTimeline: [
      {
        status: { type: String },
        note: { type: String },
        updatedBy: { type: String },
        timestamp: { type: Date, default: Date.now },
      },
    ],
    aiTriageReport: {
      riskScore: { type: Number, default: 5 }, // 1 - 10
      severityLabel: { type: String, default: 'High Priority' },
      immediateActions: [{ type: String }],
      recommendedServices: [{ type: String }],
      generatedAt: { type: Date, default: Date.now },
    },
  },
  {
    timestamps: true,
  }
);

helpRequestSchema.index({ location: '2dsphere' });
helpRequestSchema.index({ status: 1 });
helpRequestSchema.index({ category: 1 });

module.exports = mongoose.model('HelpRequest', helpRequestSchema);
