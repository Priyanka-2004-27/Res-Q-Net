import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('resqnet_token') || null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initAuth = async () => {
      const storedToken = localStorage.getItem('resqnet_token');
      if (storedToken) {
        try {
          const res = await api.get('/auth/me');
          if (res.data.success) {
            setUser(res.data.data);
          }
        } catch (err) {
          localStorage.removeItem('resqnet_token');
          setToken(null);
          setUser(null);
        }
      }
      setLoading(false);
    };

    initAuth();
  }, []);

  const login = async (email, password) => {
    const res = await api.post('/auth/login', { email, password });
    if (res.data.success) {
      const { token: receivedToken, ...userData } = res.data.data;
      localStorage.setItem('resqnet_token', receivedToken);
      setToken(receivedToken);
      setUser(userData);
      return userData;
    }
  };

  const register = async (userData) => {
    const res = await api.post('/auth/register', userData);
    if (res.data.success) {
      const { token: receivedToken, ...data } = res.data.data;
      localStorage.setItem('resqnet_token', receivedToken);
      setToken(receivedToken);
      setUser(data);
      return data;
    }
  };

  const logout = () => {
    localStorage.removeItem('resqnet_token');
    setToken(null);
    setUser(null);
  };

  const quickLogin = async (roleType) => {
    let email = 'kahan@example.com';
    let password = 'password123';

    if (roleType === 'volunteer') {
      email = 'rahul.volunteer@resqnet.org';
    } else if (roleType === 'paramedic') {
      email = 'priya.medic@resqnet.org';
    } else if (roleType === 'admin') {
      email = 'admin@resqnet.org';
    }

    return await login(email, password);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        isAuthenticated: !!user,
        login,
        register,
        logout,
        quickLogin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
