const express = require('express');
const router = express.Router();
const {
  askEmergencyAssistant,
  evaluateIncidentTriage,
  getSafetyGuides,
} = require('../controllers/aiController');

router.post('/assistant', askEmergencyAssistant);
router.post('/triage', evaluateIncidentTriage);
router.get('/safety-guides', getSafetyGuides);

module.exports = router;
