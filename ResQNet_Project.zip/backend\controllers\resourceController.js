const EmergencyResource = require('../models/EmergencyResource');
const { memoryStore } = require('../config/db');
const { calculateDistanceKm } = require('../services/geoService');

// @desc    Get all resources with optional category filter
// @route   GET /api/resources
// @access  Public
const getAllResources = async (req, res) => {
  try {
    const { type, status } = req.query;

    if (memoryStore.isUsingMemoryStore) {
      let list = [...memoryStore.resources];
      if (type) list = list.filter((r) => r.type === type);
      if (status) list = list.filter((r) => r.operationalStatus === status);
      return res.json({ success: true, count: list.length, data: list });
    }

    const filter = {};
    if (type) filter.type = type;
    if (status) filter.operationalStatus = status;

    const list = await EmergencyResource.find(filter);
    res.json({ success: true, count: list.length, data: list });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get nearby emergency resources within radius
// @route   GET /api/resources/nearby
// @access  Public
const getNearbyResources = async (req, res) => {
  try {
    const lat = parseFloat(req.query.lat);
    const lng = parseFloat(req.query.lng);
    const radiusKm = parseFloat(req.query.radius) || 20; // default 20 km
    const type = req.query.type;

    if (isNaN(lat) || isNaN(lng)) {
      return res.status(400).json({ success: false, message: 'Valid lat and lng query params are required' });
    }

    const userCoords = [lng, lat];
    let results = [];

    if (memoryStore.isUsingMemoryStore) {
      results = memoryStore.resources
        .filter((item) => {
          if (type && item.type !== type) return false;
          const dist = calculateDistanceKm(userCoords, item.location.coordinates);
          return dist <= radiusKm;
        })
        .map((item) => {
          const dist = calculateDistanceKm(userCoords, item.location.coordinates);
          return {
            ...item,
            distanceKm: dist,
          };
        })
        .sort((a, b) => a.distanceKm - b.distanceKm);

      return res.json({ success: true, count: results.length, radiusKm, data: results });
    }

    const query = {
      location: {
        $nearSphere: {
          $geometry: { type: 'Point', coordinates: [lng, lat] },
          $maxDistance: radiusKm * 1000,
        },
      },
    };

    if (type) query.type = type;

    const items = await EmergencyResource.find(query);
    results = items.map((doc) => {
      const item = doc.toObject();
      item.distanceKm = calculateDistanceKm(userCoords, item.location.coordinates);
      return item;
    });

    res.json({ success: true, count: results.length, radiusKm, data: results });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create new emergency resource (Shelter, Hospital, Fire Station)
// @route   POST /api/resources
// @access  Private (Admin / Responder)
const createResource = async (req, res) => {
  try {
    const { name, type, location, address, contactPhone, capacity, availableSupplies, operationalStatus, notes } =
      req.body;

    if (!name || !type || !location || !location.coordinates || !address || !contactPhone) {
      return res.status(400).json({ success: false, message: 'Please provide all required resource fields' });
    }

    const resourceData = {
      name,
      type,
      location,
      address,
      contactPhone,
      capacity: Number(capacity) || 100,
      currentOccupancy: 0,
      availableSupplies: availableSupplies || ['First Aid', 'Drinking Water'],
      operationalStatus: operationalStatus || 'operational',
      isVerified: true,
      notes: notes || '',
    };

    let saved;
    if (memoryStore.isUsingMemoryStore) {
      resourceData._id = '6603' + Date.now().toString().slice(-20);
      memoryStore.resources.push(resourceData);
      saved = resourceData;
    } else {
      saved = await EmergencyResource.create(resourceData);
    }

    res.status(201).json({ success: true, data: saved });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update resource occupancy count & status
// @route   PUT /api/resources/:id/occupancy
// @access  Private (Admin / Volunteer)
const updateResourceOccupancy = async (req, res) => {
  try {
    const { id } = req.params;
    const { currentOccupancy, operationalStatus } = req.body;

    if (memoryStore.isUsingMemoryStore) {
      const resItem = memoryStore.resources.find((r) => r._id.toString() === id.toString());
      if (!resItem) return res.status(404).json({ success: false, message: 'Resource not found' });

      if (currentOccupancy !== undefined) resItem.currentOccupancy = Number(currentOccupancy);
      if (operationalStatus) resItem.operationalStatus = operationalStatus;

      // Auto update status based on capacity
      if (resItem.capacity > 0 && resItem.currentOccupancy >= resItem.capacity) {
        resItem.operationalStatus = 'full';
      }

      return res.json({ success: true, data: resItem });
    }

    const resItem = await EmergencyResource.findById(id);
    if (!resItem) return res.status(404).json({ success: false, message: 'Resource not found' });

    if (currentOccupancy !== undefined) resItem.currentOccupancy = Number(currentOccupancy);
    if (operationalStatus) resItem.operationalStatus = operationalStatus;

    if (resItem.capacity > 0 && resItem.currentOccupancy >= resItem.capacity) {
      resItem.operationalStatus = 'full';
    }

    await resItem.save();
    res.json({ success: true, data: resItem });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getAllResources,
  getNearbyResources,
  createResource,
  updateResourceOccupancy,
};
