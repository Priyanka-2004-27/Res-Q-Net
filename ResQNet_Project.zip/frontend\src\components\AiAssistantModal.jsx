import React, { useState } from 'react';
import api from '../services/api';
import { Bot, X, Send, PhoneCall, HeartPulse, AlertTriangle, Waves } from 'lucide-react';

const SUGGESTIONS = [
  'How do I stop severe bleeding from an open wound?',
  'What are the step-by-step actions during an Earthquake?',
  'Basement is flooded with rising water, what should we do?',
  'How to perform hands-only CPR on an adult?',
];

export const AiAssistantModal = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState([
    {
      sender: 'ai',
      text: 'Hello, I am ResQ AI, your disaster preparedness and emergency guidance assistant. Ask any question about emergency triage, first aid steps, survival protocols, or disaster shelters.',
      actions: [
        'Call 112 for Universal Emergency Helpline',
        'Call 108 for Emergency Ambulance & Paramedics',
        'Trigger SOS to broadcast your live GPS to nearby helpers',
      ],
      numbers: [
        { service: 'Universal Emergency', number: '112' },
        { service: 'Ambulance', number: '108' },
        { service: 'Fire Brigade', number: '101' },
      ],
    },
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async (queryText) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim()) return;

    setMessages((prev) => [...prev, { sender: 'user', text: textToSend }]);
    setInputQuery('');
    setLoading(true);

    try {
      const res = await api.post('/ai/assistant', { query: textToSend });
      if (res.data.success) {
        const { response, suggestedActions, emergencyNumbers, priorityLevel } = res.data.data;
        setMessages((prev) => [
          ...prev,
          {
            sender: 'ai',
            text: response,
            priority: priorityLevel,
            actions: suggestedActions,
            numbers: emergencyNumbers,
          },
        ]);
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: '⚠️ Unable to connect to AI server. For critical emergencies, please dial 112 (Universal Emergency) or 108 (Medical Ambulance) immediately.',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content" style={{ maxWidth: '640px', height: '75vh', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '14px 18px', borderBottom: '1px solid #1f2937', display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#0f172a' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ padding: '6px', borderRadius: '8px', backgroundColor: '#4338ca' }}>
              <Bot size={20} color="#fff" />
            </div>
            <div>
              <h3 style={{ fontSize: '15px', fontWeight: '800', color: '#f8fafc', margin: 0 }}>
                ResQ AI Emergency Assistant
              </h3>
              <p style={{ fontSize: '11px', color: '#94a3b8', margin: 0 }}>
                Disaster survival & trauma guidance
              </p>
            </div>
          </div>
          <button onClick={onClose} style={{ color: '#9ca3af' }}>
            <X size={20} />
          </button>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: '16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {messages.map((msg, idx) => (
            <div
              key={idx}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: msg.sender === 'user' ? 'flex-end' : 'flex-start',
              }}
            >
              <div
                style={{
                  maxWidth: '85%',
                  padding: '12px 14px',
                  borderRadius: '10px',
                  backgroundColor: msg.sender === 'user' ? '#2563eb' : '#1e293b',
                  color: '#f8fafc',
                  fontSize: '13px',
                }}
              >
                {msg.priority && (
                  <span style={{ display: 'inline-block', marginBottom: '6px', fontSize: '10px', fontWeight: '800', padding: '2px 6px', borderRadius: '4px', backgroundColor: '#ef4444', color: '#fff' }}>
                    {msg.priority} PROTOCOL
                  </span>
                )}
                <div>{msg.text}</div>

                {msg.actions?.length > 0 && (
                  <div style={{ marginTop: '8px', paddingTop: '8px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
                    <ul style={{ paddingLeft: '16px', margin: 0, fontSize: '11px', color: '#cbd5e1' }}>
                      {msg.actions.map((act, aIdx) => (
                        <li key={aIdx}>{act}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {msg.numbers?.length > 0 && (
                  <div style={{ marginTop: '8px', display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                    {msg.numbers.map((num, nIdx) => (
                      <a
                        key={nIdx}
                        href={`tel:${num.number}`}
                        style={{
                          fontSize: '11px',
                          fontWeight: '700',
                          padding: '3px 8px',
                          borderRadius: '6px',
                          backgroundColor: '#dc2626',
                          color: '#fff',
                          textDecoration: 'none',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '4px',
                        }}
                      >
                        <PhoneCall size={10} /> {num.service}: {num.number}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          {loading && <div style={{ fontSize: '12px', color: '#94a3b8' }}>ResQ AI is analyzing emergency response...</div>}
        </div>

        <div style={{ padding: '6px 14px', borderTop: '1px solid #1f2937', backgroundColor: '#0f172a', display: 'flex', gap: '6px', overflowX: 'auto' }}>
          {SUGGESTIONS.map((sug, sIdx) => (
            <button
              key={sIdx}
              onClick={() => handleSend(sug)}
              style={{
                whiteSpace: 'nowrap',
                fontSize: '11px',
                padding: '4px 8px',
                borderRadius: '6px',
                backgroundColor: '#1e293b',
                color: '#cbd5e1',
                border: '1px solid #334155',
              }}
            >
              {sug}
            </button>
          ))}
        </div>

        <div style={{ padding: '12px 16px', borderTop: '1px solid #1f2937', backgroundColor: '#0f172a', display: 'flex', gap: '8px' }}>
          <input
            type="text"
            placeholder="Ask about first aid, burns, flooding, CPR..."
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            style={{ flex: 1 }}
          />
          <button
            onClick={() => handleSend()}
            style={{ padding: '8px 14px', borderRadius: '6px', backgroundColor: '#4338ca', color: '#fff', fontWeight: '700' }}
          >
            <Send size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};
