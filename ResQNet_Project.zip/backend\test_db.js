const mongoose = require('mongoose');
const dotenv = require('dotenv');
const {
  initialUsers,
  initialAlerts,
  initialResources,
  initialHelpRequests,
  initialSafetyGuides,
} = require('./data/seedData');

const User = require('./models/User');
const Alert = require('./models/Alert');
const EmergencyResource = require('./models/EmergencyResource');
const HelpRequest = require('./models/HelpRequest');
const SafetyGuide = require('./models/SafetyGuide');

dotenv.config();

const mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/resqnet';

async function testAndSeedDatabase() {
  console.log('========================================================');
  console.log('🔍 Testing MongoDB Connection to:');
  console.log(`   ${mongoUri.replace(/:([^:@]{3,})@/, ':****@')}`);
  console.log('========================================================\n');

  try {
    const conn = await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 5000,
    });

    console.log(`✅ SUCCESS: Connected to MongoDB! Host: ${conn.connection.host}`);
    console.log(`🗄️ Database Name: ${conn.connection.name}\n`);

    console.log('🌱 Checking and Seeding Collections with ResQNet Data...');

    // Clear and seed users
    const userCount = await User.countDocuments();
    if (userCount === 0) {
      await User.insertMany(initialUsers);
      console.log(`   ✓ Inserted ${initialUsers.length} Users (Admin, Volunteers, Citizens)`);
    } else {
      console.log(`   ℹ Users collection already has ${userCount} records`);
    }

    // Clear and seed alerts
    const alertCount = await Alert.countDocuments();
    if (alertCount === 0) {
      await Alert.insertMany(initialAlerts);
      console.log(`   ✓ Inserted ${initialAlerts.length} Disaster Alerts`);
    } else {
      console.log(`   ℹ Alerts collection already has ${alertCount} records`);
    }

    // Clear and seed resources
    const resCount = await EmergencyResource.countDocuments();
    if (resCount === 0) {
      await EmergencyResource.insertMany(initialResources);
      console.log(`   ✓ Inserted ${initialResources.length} Verified Shelters & Hospitals`);
    } else {
      console.log(`   ℹ Resources collection already has ${resCount} records`);
    }

    // Clear and seed help requests
    const helpCount = await HelpRequest.countDocuments();
    if (helpCount === 0) {
      await HelpRequest.insertMany(initialHelpRequests);
      console.log(`   ✓ Inserted ${initialHelpRequests.length} Emergency Help SOS Requests`);
    } else {
      console.log(`   ℹ HelpRequests collection already has ${helpCount} records`);
    }

    // Clear and seed safety guides
    const guideCount = await SafetyGuide.countDocuments();
    if (guideCount === 0) {
      await SafetyGuide.insertMany(initialSafetyGuides);
      console.log(`   ✓ Inserted ${initialSafetyGuides.length} Disaster Survival Guides`);
    } else {
      console.log(`   ℹ SafetyGuides collection already has ${guideCount} records`);
    }

    console.log('\n========================================================');
    console.log('🎉 ALL RESQNET DATABASE COLLECTIONS ARE READY & VERIFIED!');
    console.log('========================================================');

    await mongoose.disconnect();
    process.exit(0);
  } catch (err) {
    console.error('\n❌ MongoDB Connection Failed:', err.message);
    console.log('\n💡 Tip: Check your MONGO_URI in backend/.env file.');
    process.exit(1);
  }
}

testAndSeedDatabase();
