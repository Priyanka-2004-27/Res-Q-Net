import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useLocation } from '../context/LocationContext';
import { LifeBuoy, PhoneCall, CheckCircle, ShieldCheck } from 'lucide-react';

export const HelperDashboard = () => {
  const { user, quickLogin } = useAuth();
  const { lat, lng } = useLocation();

  const [nearbyRequests, setNearbyRequests] = useState([]);
  const [isAvailable, setIsAvailable] = useState(true);

  const fetchNearby = async () => {
    try {
      const res = await api.get(`/requests/nearby?lat=${lat}&lng=${lng}&radius=25`);
      if (res.data.success) {
        setNearbyRequests(res.data.data);
      }
    } catch (err) {
      console.warn('Helper err:', err.message);
    }
  };

  useEffect(() => {
    fetchNearby();
    const interval = setInterval(fetchNearby, 10000);
    return () => clearInterval(interval);
  }, [lat, lng]);

  const handleAccept = async (id) => {
    try {
      const res = await api.put(`/requests/${id}/accept`);
      if (res.data.success) {
        alert('Mission Accepted!');
        fetchNearby();
      }
    } catch (err) {
      alert('Accept failed.');
    }
  };

  return (
    <div className="container" style={{ padding: '24px 20px 60px' }}>
      <div style={{ backgroundColor: '#111827', borderRadius: '12px', padding: '20px', marginBottom: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <span style={{ fontSize: '10px', textTransform: 'uppercase', padding: '2px 6px', borderRadius: '4px', backgroundColor: 'rgba(16, 185, 129, 0.2)', color: '#34d399', fontWeight: '800' }}>
            Volunteer Portal
          </span>
          <h1 style={{ fontSize: '20px', fontWeight: '800', color: '#f8fafc', margin: '4px 0 0' }}>
            {user?.name || 'Rahul Sharma (Volunteer)'}
          </h1>
        </div>

        <button
          onClick={() => setIsAvailable(!isAvailable)}
          style={{ padding: '8px 14px', borderRadius: '6px', backgroundColor: isAvailable ? '#10b981' : '#334155', color: '#fff', fontSize: '12px', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '6px' }}
        >
          <ShieldCheck size={14} /> {isAvailable ? 'On Active Duty' : 'On Standby'}
        </button>
      </div>

      <h2 style={{ fontSize: '16px', fontWeight: '800', color: '#f8fafc', marginBottom: '12px' }}>
        Nearby SOS Calls Within 25 km
      </h2>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {nearbyRequests.map((req) => (
          <div key={req._id} className="resq-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
            <div>
              <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '4px' }}>
                <span className="badge badge-critical">{req.urgencyLevel}</span>
                <span style={{ fontSize: '12px', color: '#38bdf8', fontWeight: '700' }}>📍 {req.distanceKm} km away</span>
              </div>
              <h3 style={{ fontSize: '15px', fontWeight: '700', color: '#f8fafc', margin: '0 0 2px' }}>{req.title}</h3>
              <p style={{ fontSize: '12px', color: '#94a3b8', margin: 0 }}>Victim: {req.userName} ({req.userPhone})</p>
            </div>

            <div>
              {req.status === 'pending' ? (
                <button
                  onClick={() => handleAccept(req._id)}
                  style={{ padding: '8px 16px', borderRadius: '6px', backgroundColor: '#10b981', color: '#fff', fontSize: '12px', fontWeight: '700' }}
                >
                  🤝 Accept Mission
                </button>
              ) : (
                <span className="badge badge-success">Assigned</span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
