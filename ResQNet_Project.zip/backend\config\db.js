const mongoose = require('mongoose');
const {
  initialUsers,
  initialAlerts,
  initialResources,
  initialHelpRequests,
  initialSafetyGuides,
} = require('../data/seedData');

// In-Memory store for offline / zero-dependency development fallback
const memoryStore = {
  users: JSON.parse(JSON.stringify(initialUsers)),
  alerts: JSON.parse(JSON.stringify(initialAlerts)),
  resources: JSON.parse(JSON.stringify(initialResources)),
  helpRequests: JSON.parse(JSON.stringify(initialHelpRequests)),
  safetyGuides: JSON.parse(JSON.stringify(initialSafetyGuides)),
  isUsingMemoryStore: false,
};

const connectDB = async () => {
  const mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/resqnet';

  try {
    const conn = await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 3000, // Quick check
    });

    console.log(`\n======================================================`);
    console.log(`✅ MongoDB Connected Successfully: ${conn.connection.host}`);
    console.log(`🗄️ Database Name: ${conn.connection.name}`);
    console.log(`======================================================\n`);

    memoryStore.isUsingMemoryStore = false;

    // Seed database if empty
    await seedMongoIfEmpty();
  } catch (error) {
    console.log(`\n======================================================`);
    console.warn(`⚠️  Notice: MongoDB server connection not established (${error.message}).`);
    console.log(`💡 Automatically activating ResQNet High-Speed In-Memory Data Store.`);
    console.log(`✨ All Features (Auth, SOS, Geo-Search, AI Triage, Maps) will operate seamlessly!`);
    console.log(`ℹ️  To connect real MongoDB, configure MONGO_URI in .env`);
    console.log(`======================================================\n`);

    memoryStore.isUsingMemoryStore = true;
  }
};

async function seedMongoIfEmpty() {
  try {
    const User = require('../models/User');
    const Alert = require('../models/Alert');
    const EmergencyResource = require('../models/EmergencyResource');
    const HelpRequest = require('../models/HelpRequest');
    const SafetyGuide = require('../models/SafetyGuide');

    const userCount = await User.countDocuments();
    if (userCount === 0) {
      console.log('🌱 Seeding default ResQNet records into MongoDB...');
      await User.insertMany(initialUsers);
      await Alert.insertMany(initialAlerts);
      await EmergencyResource.insertMany(initialResources);
      await HelpRequest.insertMany(initialHelpRequests);
      await SafetyGuide.insertMany(initialSafetyGuides);
      console.log('✅ Database seeded with verified emergency resources, alerts, and sample users.');
    }
  } catch (seedErr) {
    console.error('Error during initial Mongo seeding:', seedErr.message);
  }
}

module.exports = {
  connectDB,
  memoryStore,
};
