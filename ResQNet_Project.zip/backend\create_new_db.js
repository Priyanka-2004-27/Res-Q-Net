const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config();

const {
  initialUsers,
  initialAlerts,
  initialResources,
  initialHelpRequests,
  initialSafetyGuides,
} = require('./data/seedData');

const User = require('./models/User');
const Alert = require('./models/Alert');
const EmergencyResource = require('./models/EmergencyResource');
const HelpRequest = require('./models/HelpRequest');
const SafetyGuide = require('./models/SafetyGuide');

// Read database name from command line argument or default to resqnet_new_db
const newDbName = process.argv[2] || 'resqnet_new_db';
const baseUri = process.env.MONGO_URI ? process.env.MONGO_URI.replace(/\/[^/?]+(\?|$)/, `/${newDbName}$1`) : `mongodb://127.0.0.1:27017/${newDbName}`;

async function createNewDatabase() {
  console.log('========================================================');
  console.log(`🚀 CREATING NEW DATABASE: [ ${newDbName} ]`);
  console.log(`🔗 Target Connection URI: ${baseUri.replace(/:([^:@]{3,})@/, ':****@')}`);
  console.log('========================================================\n');

  try {
    const conn = await mongoose.connect(baseUri, {
      serverSelectionTimeoutMS: 6000,
    });

    console.log(`✅ Connected to MongoDB server: ${conn.connection.host}`);
    console.log(`🗄️ Successfully Created / Selected Database: ${conn.connection.name}\n`);

    // Clean existing collections in this new database
    console.log('📦 Initializing Collections & Schema Structure...');
    await Promise.all([
      User.deleteMany({}),
      Alert.deleteMany({}),
      EmergencyResource.deleteMany({}),
      HelpRequest.deleteMany({}),
      SafetyGuide.deleteMany({}),
    ]);

    // Insert fresh records
    console.log('🌱 Populating fresh records:');
    const users = await User.insertMany(initialUsers);
    console.log(`   ✓ [Users Collection]: ${users.length} user accounts created`);

    const alerts = await Alert.insertMany(initialAlerts);
    console.log(`   ✓ [Alerts Collection]: ${alerts.length} disaster warning alerts created`);

    const resources = await EmergencyResource.insertMany(initialResources);
    console.log(`   ✓ [EmergencyResources Collection]: ${resources.length} verified shelters/hospitals created`);

    const requests = await HelpRequest.insertMany(initialHelpRequests);
    console.log(`   ✓ [HelpRequests Collection]: ${requests.length} SOS emergency incidents created`);

    const guides = await SafetyGuide.insertMany(initialSafetyGuides);
    console.log(`   ✓ [SafetyGuides Collection]: ${guides.length} survival manuals created`);

    // Update .env file with the new database URI
    const envPath = path.join(__dirname, '.env');
    let envContent = fs.readFileSync(envPath, 'utf8');
    if (envContent.includes('MONGO_URI=')) {
      envContent = envContent.replace(/MONGO_URI=.*/, `MONGO_URI=${baseUri}`);
    } else {
      envContent += `\nMONGO_URI=${baseUri}`;
    }
    fs.writeFileSync(envPath, envContent, 'utf8');

    console.log(`\n📝 Updated backend/.env to use: ${newDbName}`);
    console.log('\n========================================================');
    console.log(`🎉 NEW DATABASE [${newDbName}] CREATED & READY!`);
    console.log('========================================================');

    await mongoose.disconnect();
    process.exit(0);
  } catch (err) {
    console.error('\n⚠️ Notice:', err.message);
    console.log(`\n💡 Note: If MongoDB server is offline locally, ResQNet automatic In-Memory database`);
    console.log(`   is active and running seamlessly on http://localhost:3000`);
    process.exit(1);
  }
}

createNewDatabase();
