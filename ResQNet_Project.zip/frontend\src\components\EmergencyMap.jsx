import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { useLocation } from '../context/LocationContext';
import { useAuth } from '../context/AuthContext';
import {
  Layers,
  Crosshair,
  AlertTriangle,
  Building,
  Flame,
  LifeBuoy,
  Utensils,
  Shield,
  Droplet,
  Compass,
} from 'lucide-react';

export const EmergencyMap = ({
  helpRequests = [],
  resources = [],
  onAcceptRequest,
}) => {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersLayerRef = useRef(null);
  const radiusCircleRef = useRef(null);

  const { coords, lat, lng, address } = useLocation();
  const { user } = useAuth();

  const [radiusKm, setRadiusKm] = useState(25);
  const [filterType, setFilterType] = useState('all');

  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [lat, lng],
        zoom: 13,
        zoomControl: false,
      });

      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
        maxZoom: 19,
      }).addTo(map);

      L.control.zoom({ position: 'bottomright' }).addTo(map);

      const markersLayer = L.layerGroup().addTo(map);
      markersLayerRef.current = markersLayer;
      mapInstanceRef.current = map;
    }
  }, []);

  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    if (radiusCircleRef.current) {
      map.removeLayer(radiusCircleRef.current);
    }

    const radiusCircle = L.circle([lat, lng], {
      color: '#3b82f6',
      fillColor: '#3b82f6',
      fillOpacity: 0.08,
      weight: 1.5,
      dashArray: '4, 8',
      radius: radiusKm * 1000,
    }).addTo(map);

    radiusCircleRef.current = radiusCircle;
  }, [lat, lng, radiusKm]);

  useEffect(() => {
    if (!mapInstanceRef.current || !markersLayerRef.current) return;

    const layer = markersLayerRef.current;
    layer.clearLayers();

    // User GPS Marker
    const userIcon = L.divIcon({
      className: 'user-marker',
      html: `
        <div style="position:relative; width:30px; height:30px; display:flex; align-items:center; justify-content:center;">
          <div style="position:absolute; width:30px; height:30px; border-radius:50%; background:rgba(59,130,246,0.35); animation: beacon-ping 2s infinite;"></div>
          <div style="width:16px; height:16px; border-radius:50%; background:#2563eb; border:3px solid #ffffff; box-shadow:0 0 12px #2563eb;"></div>
        </div>
      `,
      iconSize: [30, 30],
      iconAnchor: [15, 15],
    });

    const userMarker = L.marker([lat, lng], { icon: userIcon });
    userMarker.bindPopup(`
      <div style="padding:8px; font-family:sans-serif;">
        <div style="display:flex; align-items:center; gap:6px; margin-bottom:4px;">
          <span style="font-size:12px; font-weight:800; color:#38bdf8;">📍 YOUR CURRENT LOCATION</span>
        </div>
        <p style="margin:0 0 6px; font-size:12px; color:#cbd5e1;">${address}</p>
        <span style="font-size:10px; color:#94a3b8;">Scanning within ${radiusKm}km perimeter</span>
      </div>
    `);
    layer.addLayer(userMarker);

    // SOS Requests Markers
    if (filterType === 'all' || filterType === 'sos') {
      helpRequests.forEach((req) => {
        if (!req.location || !req.location.coordinates) return;
        const [rLng, rLat] = req.location.coordinates;
        const isCritical = req.urgencyLevel === 'critical' || req.aiTriageReport?.riskScore >= 8;

        const sosIcon = L.divIcon({
          className: 'sos-marker',
          html: `
            <div style="position:relative; width:36px; height:36px; display:flex; align-items:center; justify-content:center;">
              <div style="position:absolute; width:36px; height:36px; border-radius:50%; background:${isCritical ? 'rgba(239,68,68,0.45)' : 'rgba(245,158,11,0.45)'}; animation: beacon-ping 1.5s infinite;"></div>
              <div style="width:26px; height:26px; border-radius:50%; background:${isCritical ? '#dc2626' : '#d97706'}; border:2px solid #fff; display:flex; align-items:center; justify-content:center; color:#fff; font-weight:bold; font-size:10px; box-shadow:0 0 10px rgba(0,0,0,0.5);">
                SOS
              </div>
            </div>
          `,
          iconSize: [36, 36],
          iconAnchor: [18, 18],
        });

        const sosMarker = L.marker([rLat, rLng], { icon: sosIcon });
        sosMarker.bindPopup(`
          <div style="min-width:240px; padding:8px; font-family:sans-serif;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
              <span style="font-size:10px; font-weight:800; padding:2px 6px; border-radius:4px; background:${isCritical ? '#ef4444' : '#f59e0b'}; color:#fff; text-transform:uppercase;">
                ${req.urgencyLevel} SOS
              </span>
              <span style="font-size:10px; font-weight:700; color:#cbd5e1; text-transform:uppercase;">
                ${req.category.replace('_', ' ')}
              </span>
            </div>
            <h4 style="margin:0 0 4px 0; color:#f8fafc; font-size:13px; font-weight:700;">${req.title}</h4>
            <p style="margin:0 0 6px 0; font-size:11px; color:#cbd5e1;">${req.description || 'Emergency assistance requested.'}</p>
            <div style="font-size:11px; color:#94a3b8; margin-bottom:8px; background:#1e293b; padding:6px; border-radius:6px;">
              <div>📍 ${req.address}</div>
              <div>👥 Casualties: <strong>${req.casualtiesCount}</strong> | AI Risk: <strong style="color:${isCritical ? '#f87171' : '#fbbf24'}">${req.aiTriageReport?.riskScore || 7}/10</strong></div>
              <div>👤 Victim: ${req.userName} (${req.userPhone})</div>
            </div>
            <a href="tel:${req.userPhone}" style="display:block; text-align:center; padding:6px; background:#dc2626; color:#fff; border-radius:6px; font-size:11px; font-weight:700; text-decoration:none;">
              📞 Call Victim Immediately
            </a>
          </div>
        `);
        layer.addLayer(sosMarker);
      });
    }

    // Resources Markers (All 8 Categories)
    resources.forEach((res) => {
      if (!res.location || !res.location.coordinates) return;
      const [resLng, resLat] = res.location.coordinates;
      if (filterType !== 'all' && filterType !== res.type) return;

      let symbol = '🏥';
      let color = '#0284c7'; // default hospital blue

      switch (res.type) {
        case 'hospital':
          symbol = '🏥';
          color = '#0284c7';
          break;
        case 'shelter':
          symbol = '⛺';
          color = '#059669';
          break;
        case 'evacuation_center':
          symbol = '🏛️';
          color = '#7c3aed';
          break;
        case 'fire_station':
          symbol = '🚒';
          color = '#ea580c';
          break;
        case 'police_station':
          symbol = '🚓';
          color = '#3b82f6';
          break;
        case 'relief_camp':
          symbol = '🏕️';
          color = '#0d9488';
          break;
        case 'food_distribution':
          symbol = '🍞';
          color = '#d97706';
          break;
        case 'blood_bank':
          symbol = '🩸';
          color = '#dc2626';
          break;
        default:
          symbol = '📍';
          color = '#64748b';
      }

      const resIcon = L.divIcon({
        className: 'resource-marker',
        html: `
          <div style="width:30px; height:30px; border-radius:8px; background:${color}; border:2px solid #ffffff; display:flex; align-items:center; justify-content:center; font-size:14px; box-shadow:0 0 10px rgba(0,0,0,0.5);">
            ${symbol}
          </div>
        `,
        iconSize: [30, 30],
        iconAnchor: [15, 15],
      });

      const resMarker = L.marker([resLat, resLng], { icon: resIcon });
      const percentOccupied = res.capacity > 0 ? Math.round((res.currentOccupancy / res.capacity) * 100) : 0;

      resMarker.bindPopup(`
        <div style="min-width:240px; padding:8px; font-family:sans-serif;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
            <span style="font-size:10px; font-weight:800; padding:2px 6px; border-radius:4px; background:${color}; color:#fff; text-transform:uppercase;">
              ${res.type.replace('_', ' ')}
            </span>
            <span style="font-size:10px; font-weight:700; color:${res.operationalStatus === 'operational' ? '#34d399' : '#f87171'};">
              ● ${res.operationalStatus}
            </span>
          </div>
          <h4 style="margin:0 0 4px 0; color:#f8fafc; font-size:13px; font-weight:700;">${res.name}</h4>
          <p style="margin:0 0 6px 0; font-size:11px; color:#cbd5e1;">📍 ${res.address}</p>
          <div style="font-size:11px; color:#94a3b8; margin-bottom:8px; background:#1e293b; padding:6px; border-radius:6px;">
            <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
              <span>Capacity:</span>
              <strong style="color:#f8fafc;">${res.currentOccupancy} / ${res.capacity} (${percentOccupied}%)</strong>
            </div>
            <div style="background:#334155; height:5px; border-radius:3px; overflow:hidden;">
              <div style="background:${percentOccupied > 80 ? '#ef4444' : '#10b981'}; width:${Math.min(percentOccupied, 100)}%; height:100%;"></div>
            </div>
            <div style="margin-top:6px; font-size:10px; color:#cbd5e1;">
              Supplies: ${(res.availableSupplies || []).slice(0, 3).join(', ')}
            </div>
          </div>
          <a href="tel:${res.contactPhone}" style="display:block; text-align:center; padding:6px; background:#2563eb; color:#fff; border-radius:6px; font-size:11px; font-weight:700; text-decoration:none;">
            📞 Call ${res.contactPhone}
          </a>
        </div>
      `);
      layer.addLayer(resMarker);
    });
  }, [helpRequests, resources, lat, lng, filterType]);

  return (
    <div style={{ position: 'relative', width: '100%', height: '540px', borderRadius: '14px', overflow: 'hidden', border: '1px solid #334155' }}>
      <div style={{
        position: 'absolute',
        top: '12px',
        left: '12px',
        right: '12px',
        zIndex: 1000,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '8px',
        pointerEvents: 'none',
      }}>
        {/* Category Filter Ribbon */}
        <div style={{
          display: 'flex',
          gap: '6px',
          background: 'rgba(15, 23, 42, 0.92)',
          padding: '6px',
          borderRadius: '10px',
          backdropFilter: 'blur(8px)',
          border: '1px solid #334155',
          pointerEvents: 'auto',
          overflowX: 'auto',
          maxWidth: '100%',
        }}>
          {[
            { id: 'all', label: 'All Services', icon: Layers },
            { id: 'sos', label: 'SOS Distress', icon: AlertTriangle },
            { id: 'hospital', label: 'Hospitals', icon: Building },
            { id: 'shelter', label: 'Shelters', icon: LifeBuoy },
            { id: 'evacuation_center', label: 'Evac Centers', icon: Compass },
            { id: 'fire_station', label: 'Fire & Rescue', icon: Flame },
            { id: 'police_station', label: 'Police', icon: Shield },
            { id: 'food_distribution', label: 'Food & Ration', icon: Utensils },
            { id: 'blood_bank', label: 'Blood Banks', icon: Droplet },
          ].map((cat) => {
            const Icon = cat.icon;
            const isSelected = filterType === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setFilterType(cat.id)}
                style={{
                  padding: '6px 10px',
                  borderRadius: '6px',
                  fontSize: '11px',
                  fontWeight: '700',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  whiteSpace: 'nowrap',
                  backgroundColor: isSelected ? '#2563eb' : 'transparent',
                  color: isSelected ? '#ffffff' : '#94a3b8',
                  border: isSelected ? '1px solid #3b82f6' : '1px solid transparent',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                }}
              >
                <Icon size={12} />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Radius Selector */}
        <div style={{ display: 'flex', gap: '8px', pointerEvents: 'auto' }}>
          <select
            value={radiusKm}
            onChange={(e) => setRadiusKm(Number(e.target.value))}
            style={{
              background: '#1e293b',
              color: '#38bdf8',
              fontSize: '11px',
              fontWeight: '700',
              padding: '6px 10px',
              border: '1px solid #334155',
              borderRadius: '8px',
              width: 'auto',
              cursor: 'pointer',
            }}
          >
            <option value={5}>Radius: 5 km</option>
            <option value={10}>Radius: 10 km</option>
            <option value={25}>Radius: 25 km</option>
            <option value={50}>Radius: 50 km</option>
          </select>
        </div>
      </div>

      <div ref={mapContainerRef} style={{ width: '100%', height: '100%' }} />
    </div>
  );
};
